# Bản ghép V1 đến kết · Phiên bản 03

Giữ nguyên phần V1–4.2 bản 02 (03:08), nối phần tiếp theo (03:53), tổng khoảng 07:01. Dự án HTML này có đầy đủ các cảnh và tài sản để chỉnh sửa lại. Video xuất ghép dùng hai bản 4K đã kiểm tra để không phải dựng lại các thao tác cũ.

# LTH Style · Odoo · 4.3, V2–4.4, 4.5 và kết

Phần tiếp theo của bản 02. 4K 3840 × 2160, 16:9, 30 fps. Nền sáng, tím Odoo, Be Vietnam Pro. Không có thuyết minh hoặc nhạc; không thêm hiệu ứng chuyển cảnh, zoom hoặc đường tiến trình phía dưới. Footage thao tác được giữ đủ từ đầu đến cuối ở tốc độ 1×.

## Nội dung và thời lượng
- 00:00: 4.3 — kho hàng, vị trí, kiểm tra tồn và phiếu nhập. Kho thực tế hiển thị là LTH Style – Kho trung tâm. Cảnh nhận hàng dùng P00006 / LTH/IN/00002, 17 váy babydoll Đen, M; đã ghi rõ đây là ví dụ chứng từ khác với P00008 của phần 4.2.
- 00:49: Mở đầu V2–4.4.
- 00:55: Giữ đủ 90 giây clip V2, theo dõi S00110, phiếu lấy hàng LTH/PICK/00051, phiếu giao LTH/OUT/00045, hóa đơn INV/2026/00023 và kiểm tra tồn.
- 02:25: 4.5 — 64 giây đối chiếu báo cáo và quyết định quản trị. Dùng khung hình gốc từ Sales Analysis/Forecast của V1 và từ kết quả giao hàng/tồn của V2; không dựng dashboard hoặc chứng từ mới.
- 03:29: Kết — hai đề xuất rà soát hằng ngày và hằng tuần, rồi kết thúc phần mô phỏng.
- Tổng: khoảng 03:53. Ghép nối nguyên bản với video V1–4.2 bản 02 cho thời lượng khoảng 07:01. Thời lượng tăng vì giữ đủ thao tác theo yêu cầu.

## Điểm đối chiếu nội dung
- V2 chọn Váy babydoll cổ vuông Đen, M, mã LTH-V001-DEN-M, tách biệt ví dụ giả định trước triển khai.
- Đơn S00110 có 5 chiếc, giảm 20%; giao hoàn tất đủ 5; tồn tại thời điểm kiểm tra 26. Không dùng biểu đồ 31→26 vì chưa loại trừ được giao dịch khác giữa hai mốc tồn.
- INV/2026/00023 liên kết S00110, tổng 1.271.600 đ. Chỉ ghi “Đã thanh toán” từ thời điểm màn hình thể hiện trạng thái thật, khoảng giây 81 của clip gốc.
- Clip V2 đã có bố cục, zoom, khung đánh dấu và nhãn bên ngoài. Lấy cố định vùng Odoo 1500×846 tại (210,74), bỏ các nhãn ngoài giao diện vốn có điểm gây nhầm; giữ nguyên dữ liệu, con trỏ và phần zoom/đánh dấu đã được nhúng trong vùng Odoo. Không dựng lại màn hình.
- Khoảng giây 20–28 của clip V2 là quy tắc bổ sung của Quần ống rộng nữ Đen, M (tối thiểu 20, tối đa 40), không phải váy. Chú thích mới xác định đúng sản phẩm và yêu cầu kiểm tra quy tắc của đúng biến thể, không chép nhãn cũ “tối đa 35 / hiện còn 31”.
- Các cảnh tồn kho thuộc từng thời điểm quay riêng. Không kết luận đã xử lý xong một đơn thiếu hàng cụ thể chỉ từ chúng.

## Phần nguồn còn thiếu
`4.3.5. Replenishment. Reordering Rules.mp4` vượt giới hạn tải 32 MiB/tệp nên chưa nằm trong bản này. Cần chia thành các đoạn dưới 32 MiB để bổ sung trọn thao tác riêng. Cảnh tham chiếu bổ sung trong V2 không được coi là đã thay thế đầy đủ clip 4.3.5 này.

## Dự án và kiểm tra
- `index.html`: nguồn HyperFrames; `assets/`: video và khung đối chiếu.
- `edit-plan.json`: timeline; `source-edits.json`: nguồn, điểm trích ảnh và phần chưa truy cập được.
- Các khung đối chiếu là ảnh thật được trích từ footage, có mục đích đọc báo cáo, không giả làm thao tác mới. Khung phiếu giao trong phần 4.5 tập trung vào vùng chứng từ để đọc số lượng rõ hơn.

Kiểm tra: `HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.8.216 check`

Xuất: `HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.8.216 render --output renders/LTH-Odoo-4.3-4.5-Ket-4K-v1.mp4 --fps 30 --resolution landscape-4k --quality high --crf 16 --workers 4 --video-frame-format png`
