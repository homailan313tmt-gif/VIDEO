# LTH Style · Odoo continuation

## Style Prompt
Continue the approved light technical identity from version 02: white/pale lavender, Odoo purple, Be Vietnam Pro, original Odoo recordings in a large central viewport and Vietnamese commentary outside. Hard cuts, no added transitions, no added animated zoom, no bottom progress line, no narration or music.

## Colors
- #FFFFFF — canvas
- #F6F2F6 — chapter and decision cards
- #714B67 — Odoo purple and badges
- #29232A — main text
- #625765 — secondary text

## Typography
Local Be Vietnam Pro 400 and 900. All Vietnamese accents in NFC. Preserve the previous type sizes and spacious layout.

## Footage
Play all accessible new recordings from beginning to end at 1× speed. The supplied V2 file already has zooms and annotations baked in: use a fixed 1500×846 crop at (210,74) to retain its entire Odoo window while excluding misleading outer captions and the pre-existing bottom step strip. Do not redraw, alter or reconstruct UI content. Retain original internal annotations and zooms; no new ones are added. Distinguish the rule shown for trousers from the dress used in the sale. Warehouse/stock recordings are snapshots at separate times; never turn them into unverified before/after claims.

## Reporting
Use explicitly labelled reference stills from actual recordings. No fabricated dashboards. Use delivered 5 and current stock 26, without asserting a causal 31→26 inventory change. Invoice paid status is supported by the actual invoice screen at 81–84 seconds. Conclusion has two proposals: daily order/stock review and weekly collection/sell-through review.

## What NOT to Do
- Do not invent a warehouse address or reuse supplier/dress figures for a different product.
- Do not declare an invoice paid before the UI proves it.
- Do not claim a specific stockout order is resolved without evidence.
- Do not crop within an Odoo data field or paint new values over UI.
- Do not add transitions, running bars or narration.
