# Nhóm 11 · Intro và outro

## Style Prompt
Tiếp nối phong cách infographic sáng, kỹ thuật và tiết chế của video Odoo đã duyệt. Chữ lớn, khoảng trống rộng, tím Odoo; biểu tượng logistics nét mảnh và chuyển động nhẹ ở đầu clip. Hai video riêng, mỗi video đúng 5 giây, khổ YouTube 16:9, xuất 3840 × 2160 ở 30 fps.

## Colors
- #FFFFFF: nền và chữ trên khối tím.
- #F6F2F6: nền lavender nhạt.
- #714B67: tím Odoo, khối nhận diện nhóm.
- #29232A: chữ chính.
- #625765: chữ phụ.

## Typography
Be Vietnam Pro 400 và 900, phông cục bộ hỗ trợ đầy đủ dấu tiếng Việt. Tiêu đề 100–112 px, số nhóm khoảng 220 px, thông tin lớp 34–38 px trên bố cục 1920 × 1080.

## Content
Intro: DỰ ÁN NHÓM – E-LOGISTICS TRÊN ODOO; Nhóm 11; Lớp 49K22.4.
Outro: CẢM ƠN BẠN ĐÃ THEO DÕI!; Nhóm 11 · Lớp 49K22.4.

## Motion
Mỗi clip có một cảnh duy nhất. Chữ và biểu tượng hiện nhẹ bằng opacity, tịnh tiến 8–18 px hoặc scale 0.97 đến 1. Toàn bộ nội dung đọc chính hiện đầy đủ trước 0,8 giây và giữ đến khung hình cuối. Ba easing power2.out, power3.out, sine.out. Không chuyển cảnh giữa các scene; không fade-out làm hụt chữ ở cuối.

## What NOT to Do
- Không thêm tên thành viên, tên trường hoặc thông tin chưa được cung cấp.
- Không thêm thanh tiến độ chạy dưới video.
- Không thêm thuyết minh, nhạc hoặc hiệu ứng âm thanh.
- Không sửa, nối hay kéo dài bản thực hành 5:59 hiện có.
- Không dùng hiệu ứng mạnh hoặc tái tạo màn hình Odoo.
