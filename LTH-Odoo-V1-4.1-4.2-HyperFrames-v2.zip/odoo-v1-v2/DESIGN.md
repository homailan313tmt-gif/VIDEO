# Odoo V1 · Bản 02

## Style Prompt
Keep the approved light technical visual identity: white/pale lavender canvas, Odoo purple, Be Vietnam Pro. Original Odoo footage occupies the large central viewport with Vietnamese labels outside it. The user explicitly requested removal of scene effects and the running bottom line, and completion of all recorded operations.

## Colors
- #FFFFFF — canvas and media backing
- #F6F2F6 — chapter ground
- #714B67 — Odoo purple headings and section badges
- #29232A — main text
- #625765 — secondary text

## Typography
Locally embedded Be Vietnam Pro Regular 400 and Black 900. Full Vietnamese accents, original approved title and caption sizes.

## Motion and editing
User revision overrides animation defaults: direct cuts, no fades, no entrance effects, no animated zoom, no bottom progress line. Every selected source video plays in full, at 1× speed, with all split parts joined in source order. No freeze-frame substitutes for missing actions. Use contain framing so original screen content is not cropped. The user's request to keep operations complete takes precedence over earlier approximate section durations.

## What NOT to Do
- Do not redraw or replace Odoo text, quantities, records, dates, states or cursor movements.
- Do not cut within a recorded action or skip the last confirmation/closed dialog.
- Do not add scene effects, progress bars, narration or music.
- Do not infer missing stock quantities or payment state.
- Keep the Đen, S overview separate from the Đen, M detailed demo.
