# LTH Style · Odoo V1, 4.1, 4.2 · Bản 02

Bản sửa theo yêu cầu: bỏ hoàn toàn hiệu ứng chuyển cảnh, hiệu ứng xuất hiện và phóng to; bỏ đường tiến trình phía dưới; giữ các video thao tác được chọn từ đầu đến cuối ở tốc độ 1×; bổ sung đủ hai cặp clip 4.1.2 và 4.2.4. Không có lời thuyết minh hoặc âm thanh.

Giữ nền sáng, tím Odoo và phông Be Vietnam Pro đã thống nhất. Đầu ra 3840 × 2160, 16:9, 30 fps, H.264/yuv420p. Thời lượng khoảng 3 phút 08 giây. Video gốc là Full HD và khoảng 2.5K–2.9K, được nâng lên độ phân giải xuất 4K.

## Timeline
- 00:00: Giới thiệu.
- 00:05: V1 — toàn bộ video thô thaotacOdoo v1, gồm cả trở lại Forecast sau khi nhận hàng. Ví dụ Đen, S.
- 00:58: 4.1 — danh sách và danh mục; đủ hai phần 4.1.2; thuộc tính màu sắc/kích cỡ; danh sách/thẻ biến thể; đối chiếu mã và tồn. Demo chi tiết chuyển sang Đen, M.
- 02:03: 4.2 — nguồn cung; đủ hai phần 4.2.4 theo đúng thứ tự, từ RFQ đến gửi báo giá, xác nhận đơn mua và hoàn tất phiếu nhập; tiếp tục xem chi tiết liên kết ở 4.2.5 đến lúc đóng hộp chi tiết.
- 03:04: Thẻ nối sang 4.3.

Không dựng lại giao diện, sửa số liệu, mô phỏng con trỏ hoặc thay đổi trạng thái chứng từ. Khung contain hiển thị đủ màn hình gốc. Không cắt nội bộ, không chồng lấn thời gian giữa các clip, không dùng ảnh đứng thay cho thao tác. Các cặp clip được nối theo đúng thứ tự gửi; điểm chia do tệp nguồn được giữ nguyên.

4.1.4 là bảng giá xả hàng V2, để ngoài phạm vi này. v1 (2) là bản tổng quan đã dựng; dùng toàn bộ footage thô tương ứng để thao tác không bị thiếu. Tồn kho ở các clip thuộc thời điểm kiểm tra riêng, không suy diễn thành lượng thiếu hoặc lượng cần mua.

## Dự án HyperFrames
`index.html` là nguồn video đầy đủ; `assets/` gồm các clip đã nối và chuyển về H.264 30 fps để phát nhất quán. `edit-plan.json` ghi thời điểm từng cảnh; `source-edits.json` ghi nguồn và số khung hình.

Kiểm tra:
`HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.8.216 check`

Xuất:
`HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.8.216 render --output renders/LTH-Odoo-V1-4.1-4.2-4K-v2.mp4 --fps 30 --resolution landscape-4k --quality high --crf 16 --workers 4 --video-frame-format png`

Lint, runtime, layout, motion và contrast đã đạt trong `check-final.json`. Cảnh tĩnh và không có âm thanh là chủ đích theo yêu cầu. Chú thích phụ được giữ đúng thiết kế trước, ưu tiên diện tích giao diện cho video YouTube.
