# LTH Style — Đoạn 3
## Style Prompt
Infographic 2D và video Haravan thật, đồng bộ Đoạn 1–2. Burgundy #800020; kem #FFF8EC; chữ #302327; thẻ hồng nhạt #EEDDE1; đường kẻ #DAC5C8. Be Vietnam Pro. 3840×2160, 30fps, 120 giây. Không lời thoại, không âm thanh. Fade nhẹ 0.6 giây; không wipe hoặc trượt ngang.
## Layout
Lề 160px, tiêu đề 112px. Hai cảnh màn hình: khung trái 2440×1282, thẻ giải thích phải 940px. Hai cảnh lý thuyết: infographic lớn, nhãn Minh họa lý thuyết rõ ràng. Cảnh cuối ảnh kiện chân thực bên trái và checklist minh họa bên phải.
## Data and Scope
SKU LTH-A2D-REN-001-TR-FS, màu Trắng, kho LTH Style Đà Nẵng, chỉ tiêu Tồn: 3. Không tự gọi chỉ tiêu này là tồn khả dụng. Video đã che số điện thoại và địa chỉ kho. FEFO có hạn dùng giả định, không coi ngày đóng gói là hạn dùng. Không nói đã kiểm đếm áo thực tế. Ảnh đóng gói trong dự án demo không minh chứng SKU, ngày đóng gói, hạn dùng hoặc nội dung bên trong.
## Motion
Fade theo cụm chữ, thẻ xuất hiện lần lượt. Hai kiện A/B được phân biệt bằng hạn dùng giả định, ưu tiên A có hạn sớm hơn. Thời gian giữ hình để đọc được nội dung.
