# Đoạn 3 — Quản lý tồn kho và nguyên tắc xuất hàng

Nhóm 11 · Lớp 49K22.4 · LTH Style.

120 giây · 4K 3840×2160 · 16:9 · 30fps · Không lời thoại, không âm thanh. Burgundy #800020 và kem #FFF8EC, chuyển cảnh fade nhẹ 0.6 giây.

## Nội dung
- 00:00–00:35: Tồn kho theo biến thể, đúng SKU, màu, quy cách và kho.
- 00:35–01:05: SKU LTH-A2D-REN-001-TR-FS, màu Trắng, kho LTH Style Đà Nẵng, chỉ tiêu “Tồn”: 3.
- 01:05–01:25: FEFO với hai kiện A/B và hạn dùng giả định; ghi rõ Minh họa lý thuyết.
- 01:25–01:40: Ngày đóng gói khác hạn sử dụng; phạm vi kiểm tra nhãn và sắp xếp thủ công.
- 01:40–02:00: Ảnh đóng gói dự án demo, checklist minh họa kiểm tra trước khi xuất; dẫn sang cấu hình GHN.

Khi ghép sau Đoạn 1 và 2, phần này tương ứng 03:00–05:00.

## Tư liệu và phạm vi
Clip Haravan nguồn do người dùng cung cấp ở 1080p, cắt bỏ thanh trình duyệt và phần chờ tải trang; đã che số điện thoại, địa chỉ kho. Hai clip timed có nhịp chậm hơn để đọc dữ liệu. Ảnh kiện từ 7ebc8f7337a9b7f7eeb8.zip, chú thích rõ Hình ảnh đóng gói trong dự án demo. Font và chữ infographic dựng trên khung 4K.

Không đổi chỉ tiêu “Tồn” thành “tồn khả dụng”. Không khẳng định đã kiểm đếm/đối chiếu áo ngoài đời. Không suy ra ngày đóng gói hoặc hạn sử dụng từ chữ trên kiện. Các ngày FEFO hoàn toàn giả định; không sử dụng minh họa để khẳng định Haravan đang quản lý lô/hạn dùng.

## Chỉnh sửa
Cần Node.js 22+, FFmpeg, Chromium. HyperFrames ghim phiên bản 0.9.38.

```bash
npm run check
npm run render -- --output doan3.mp4 --fps 30 --quality high
```

index.html là composition, build.py tái tạo HTML. assets/ chứa hai clip đã cắt, chỉnh nhịp, che thông tin riêng tư và tắt âm thanh; ảnh kiện, logo GHN và font. Không bao gồm bản ghi gốc chưa che thông tin.
