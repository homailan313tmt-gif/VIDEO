# LTH Style · 4.1.4 · Chính sách giá

## Style Prompt
Giữ phong cách kỹ thuật rõ ràng đã duyệt: nền sáng, tím Odoo, phông Be Vietnam Pro; video thao tác thật trong khung lớn, giải thích tiếng Việt ở ngoài khung UI. Đoạn riêng 26 giây, 16:9, xuất 4K 3840×2160 ở 30 fps.

## Colors
- #FFFFFF — nền.
- #F6F2F6 — nhấn nhạt.
- #714B67 — tím Odoo, badge và thống kê.
- #29232A — chữ chính.
- #625765 — chữ phụ.

## Typography
Be Vietnam Pro cục bộ, 400 và 900, dấu tiếng Việt NFC. Kế thừa khung 1920×1080 từ bản thực hành: header 64 px, màn hình 1824×800, caption 30 px và ghi chú 28 px.

## Footage and timing
Nguồn: 4.1.4.mp4, 2558×1248, 563 khung hình ở 30 fps, dài 18,7667 giây. Giữ đủ từ đầu đến cuối ở 1×, không crop hay zoom. Sau đó giữ nguyên khung hình cuối 217 frame (7,2333 giây), tổng 780 frame = 26 giây. Không thêm chuyển cảnh hoặc thanh tiến độ.

## Evidence
Sáu mẫu và 48 biến thể được thấy ở danh sách: 6+9+9+6+9+9. Tên bảng giá nêu 18 SKU và tháng 11/2026. Các dòng chính sách thể hiện chiết khấu 10%, 15%, 20%, bắt đầu 01/11 và kết thúc 30/11. Dòng LTH-Q001-NAU-M thể hiện quần Nâu/M giảm 20%; giá niêm yết của mẫu quần là 299.000đ. Giá 239.200đ là phép tính 299.000×(1−20%), chỉ ghi bên ngoài UI như ví dụ tính giá, không giả làm giá giao dịch hay thay số liệu trong Odoo.

## What NOT to Do
- Không thay hoặc vẽ lại bất kỳ nội dung giao diện nào.
- Không cắt ngang thao tác hoặc tăng tốc video nguồn.
- Không phủ lời giải thích lên các ô số liệu.
- Không thêm hiệu ứng cảnh hoặc thanh timeline chạy phía dưới.
- Không tạo giọng đọc mới; chưa có bản thu riêng 4.1.4, nên xuất bản hình im lặng để ghép voice của người dùng.
