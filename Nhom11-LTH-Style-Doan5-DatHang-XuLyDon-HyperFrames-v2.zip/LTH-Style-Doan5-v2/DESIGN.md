# LTH Style — Đoạn 5 v2

## Style

Giữ 3840×2160, 16:9, 30fps, 240 giây, Be Vietnam Pro. Burgundy #800020, kem #FFF8EC, chữ #302327, thẻ #EEDDE1, đường kẻ #DAC5C8. Chỉ fade 0.6 giây, không trượt ngang. Không lời thoại, không âm thanh, không ghi chú chân cảnh hay chữ báo đã che.

## Requested changes

- Bỏ kéo chậm khoảng 11 giây thao tác chọn hàng thành 40 giây. Chuẩn bị clip chọn hàng ở tốc độ gốc.
- Thay cảnh sơ đồ checkout bằng nguồn quay mới dài 51.463733 giây: giỏ hàng, điền thông tin, chọn địa chỉ, kiểm tra thanh toán và bấm đặt hàng. Cắt phần cuộn ngoài luồng và phần lặp sau khi gửi.
- Người dùng chỉ định dùng lại ảnh đơn cũ cho đoạn kết quả đặt hàng. Hiển thị kết quả ghi nhận trên Haravan bằng ảnh đã đồng bộ mã và thời gian, không dựng trang cảm ơn website giả.
- Đồng bộ chữ mã đơn trong bản dựng: Haravan #10029, GHN GYENL6TA theo phiếu gửi đoạn 6.
- Duy trì blur một phần số điện thoại và số nhà từ bản trước; không có nhãn báo đã che.

## Provenance

Ảnh Haravan đầu vào vốn là #10030; bản dựng đổi phần hiển thị sang #10029 theo yêu cầu người dùng. Ngày tạo hiển thị 11/11/2026 17:38 theo chỉnh sửa đã được yêu cầu trước đó. Ảnh GHN dùng bản dự án đã chỉnh thành GYENL6TA và COD 0đ. Điện thoại hiển thị trong clip checkout dùng lại bản đã blur một phần từ ảnh đơn cũ để thống nhất phần liên hệ với nguồn trước. Các thay đổi hiển thị không phải thao tác sửa dữ liệu trong hệ thống Haravan hoặc GHN.

## Timing

0–12s: chọn biến thể ở tốc độ gốc. 12–20s: giỏ hàng. 20–40s: điền thông tin nhận. 40–43s: thanh toán và bấm đặt hàng. 43–58s: ảnh đơn Haravan cũ cho kết quả ghi nhận. 58–80s: đối chiếu thông tin đơn. Từ 80s giữ các mốc của bản trước: quản trị, kiểm tồn/soạn, đóng gói, GHN và phân biệt mã. Tổng 240s.

## Numbers

SKU LTH-A2D-REN-001-TR-FS, Trắng, số lượng1, giá69.000đ. Phí giao trên website15.000đ, tổng đơn84.000đ. Cước GHN16.500đ là trường riêng trên nguồn vận đơn, không thay tổng đơn thành85.500đ. COD0đ, chuyển khoản ngân hàng, trạng thái Haravan Đã thanh toán/Chưa giao hàng. Giữ nhãn chỉ tiêu tồn như nguồn, không suy diễn biến động tồn.
