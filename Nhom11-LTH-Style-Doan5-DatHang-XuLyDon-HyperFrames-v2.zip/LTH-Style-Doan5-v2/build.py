from pathlib import Path
import json,re

p=Path(__file__).parent

def header():return '<div class="top"><span>NHÓM 11 · LỚP 49K22.4</span><span>ĐOẠN 05 · KHÁCH ĐẶT VÀ XỬ LÝ ĐƠN</span></div>'
def head(title,sub):return f'<div class="heading"><div class="kicker">LTH STYLE · HẬU CẦN ĐẦU RA</div><h1>{title}</h1><p>{sub}</p></div>'
def media(title,sub,side):return header()+head(title,sub)+'<div class="main-row"><div class="proof-card"><div class="screen-label">WEBSITE LTH STYLE</div><div class="video-slot"></div></div><aside>'+side+'</aside></div>'
def order_image():return '<div class="order-outer" data-layout-allow-overflow><div class="native-order"><img src="assets/order-safe.png" alt="Thông tin đơn trên Haravan"/><div class="order-id">#10029</div><div class="demo-date">11/11/2026 17:38</div></div></div>'

scenes=[]
scenes.append({'start':0,'duration':12,'type':'product','media':True,'html':media('Khách chọn sản phẩm','Áo 2 dây viền cổ phối ren · Màu Trắng','<div class="kicker">BIẾN THỂ ĐƯỢC CHỌN</div><h3>Màu Trắng</h3><div class="sku">LTH-A2D-REN-001-TR-FS</div><div class="price">69.000<span>đồng</span></div><div class="small-card">Số lượng: 1</div><p>Kiểm tra quy cách và giá trước khi đặt.</p>')})
scenes.append({'start':12,'duration':8,'type':'cart','media':True,'html':media('Giỏ hàng và thanh toán','Kiểm tra sản phẩm trước khi tiếp tục','<div class="kicker">GIỎ HÀNG</div><h3>1 sản phẩm</h3><div class="state light">Áo 2 dây · Trắng</div><div class="price">69.000<span>đồng tiền hàng</span></div><div class="small-card">Chuyển đến biểu mẫu nhận hàng</div>')})
scenes.append({'start':20,'duration':20,'type':'form','media':True,'html':media('Điền thông tin nhận hàng','Họ tên → Điện thoại → Địa chỉ → Khu vực','<div class="kicker">THÔNG TIN GIAO HÀNG</div><div class="form-check fc0"><small>NGƯỜI NHẬN</small><strong>Nguyễn Phượng Hằng</strong></div><div class="form-check fc1"><small>LIÊN HỆ</small><strong>Đối chiếu theo đơn</strong></div><div class="form-check fc2"><small>ĐỊA CHỈ</small><strong>Hoàng Diệu · Hải Châu</strong></div><div class="form-check fc3"><small>KHU VỰC</small><strong>Đà Nẵng</strong></div>')})
scenes.append({'start':40,'duration':3,'type':'payment','media':True,'html':media('Kiểm tra và bấm đặt hàng','Phương thức thanh toán và tổng tiền','<div class="kicker">THANH TOÁN</div><h3>Chuyển khoản ngân hàng</h3><div class="metric-line"><small>TỔNG THANH TOÁN</small><strong>84.000đ</strong></div><div class="small-card">Phí giao trên website: 15.000đ</div>')})
scenes.append({'start':43,'duration':15,'type':'success','html':header()+head('Đặt hàng thành công','Đơn được ghi nhận trên Haravan')+'<div class="main-row"><div class="proof-card"><div class="screen-label">HARAVAN · ĐƠN #10029</div><div class="image-stage">'+order_image()+'</div></div><aside><div class="success-mark">✓</div><div class="kicker">ĐƠN ĐÃ ĐƯỢC GHI NHẬN</div><h3>#10029</h3><div class="state">Đã thanh toán</div><div class="small-card">11/11/2026 · 17:38</div></aside></div>'})
scenes.append({'start':58,'duration':22,'type':'recap','html':header()+head('Đối chiếu thông tin sau đặt hàng','Sản phẩm · Người nhận · Thanh toán')+'''<div class="recap-grid"><div class="recap-card rc0"><small>SẢN PHẨM TRONG ĐƠN</small><h3>Áo 2 dây · Trắng</h3><p class="recap-sku">LTH-A2D-REN-001-TR-FS</p><div class="recap-price">69.000đ</div><div class="small-card">Số lượng: 1</div></div><div class="recap-card rc1"><small>THÔNG TIN NHẬN HÀNG</small><h3>Nguyễn Phượng Hằng</h3><p>Hoàng Diệu</p><p>Phường Hải Châu</p><p>Thành phố Đà Nẵng</p></div><div class="recap-card recap-dark rc2"><small>THANH TOÁN TRÊN WEBSITE</small><h3>Chuyển khoản</h3><p>Tiền hàng: 69.000đ</p><p>Phí giao: 15.000đ</p><div class="recap-price">84.000đ</div><div class="recap-paid">Đã thanh toán</div></div></div>'''})
for item in json.loads((p/'later-scenes.json').read_text()):scenes.append(item)

css=(p/'style.css').read_text()+r'''
.media-scene .main-row{flex:none;height:1320px;margin-top:110px}.screen-video{top:789px}.checkout-video{z-index:35}
.form-check{display:flex;flex-direction:column;gap:18px;padding:22px 0;border-bottom:2px solid var(--line)}.form-check small{font-size:35px;color:#73505a;letter-spacing:3px}.form-check strong{font-size:64px;line-height:1.45;color:var(--b)}
.success-mark{width:165px;height:165px;display:flex;align-items:center;justify-content:center;border:5px solid var(--b);border-radius:50%;color:var(--b);font-size:100px;font-weight:800}
.recap-grid{display:flex;gap:60px;align-items:center;justify-content:space-between;flex:1;min-height:0}.recap-card{width:1130px;height:1120px;border:2px solid var(--line);border-radius:28px;background:var(--p);padding:55px 45px;display:flex;flex-direction:column;gap:40px}.recap-card small{font-size:36px;letter-spacing:3px;color:#73505a;font-weight:800}.recap-card h3{font-size:81px;line-height:1.4;color:var(--b);letter-spacing:-2px}.recap-card p{font-size:58px;line-height:1.6}.recap-card .recap-sku{font-size:47px;letter-spacing:-2px;white-space:nowrap}.recap-price{font-size:140px;font-weight:900;letter-spacing:-5px;line-height:1.2;margin-top:auto;color:var(--b)}.recap-dark{background:var(--b);border-color:var(--b);color:var(--c)}.recap-dark small,.recap-dark h3,.recap-dark .recap-price{color:var(--c)}.recap-paid{font-size:56px;padding-top:25px;border-top:2px solid #ad5c70;font-weight:800}
'''
body='';js='window.__timelines=window.__timelines||{};const tl=gsap.timeline({paused:true});\n'
for i,s in enumerate(scenes):
    t=s['start'];total=s['duration']+(.65 if i<len(scenes)-1 else 0)
    body+=f'<section id="s{i}" class="clip scene'+(' media-scene' if s.get('media') else '')+f'" style="z-index:{i*10}" data-start="{t}" data-duration="{total}" data-track-index="{i+1}"><div class="scene-content" data-layout-allow-overlap data-hold="Khoảng dừng đọc ảnh, đối chiếu thông tin và quy trình">{s["html"]}</div></section>'
    if i:js+=f"tl.from('#s{i}',{{opacity:0,duration:.6,ease:'sine.inOut'}},{t});\n"
    js+=f"tl.from('#s{i} .top',{{opacity:0,duration:.6,ease:'power1.out'}},{t+.12});tl.from('#s{i} .heading',{{opacity:0,duration:.7,ease:'sine.out'}},{t+.2});\n"
    typ=s['type']
    if s.get('media'):
        if typ!='payment':js+=f"tl.from('#s{i} .proof-card',{{opacity:0,duration:.8,ease:'power2.out'}},{t+.55});\n"
        if typ=='form':
            js+="tl.from('#s2 aside>.kicker',{opacity:0,duration:.7,ease:'power1.out'},20.6);\n"
            for k,when in enumerate([22,27.5,33,37]):js+=f"tl.from('#s2 .fc{k}',{{opacity:0,duration:.6,ease:'power2.out'}},{when});\n"
        else:js+=f"tl.from('#s{i} aside>*',{{opacity:0,duration:.6,stagger:.2,ease:'power2.out'}},{t+.7});\n"
    elif typ in ['success','order','ghn']:
        js+=f"tl.from('#s{i} .proof-card',{{opacity:0,duration:.9,ease:'power2.out'}},{t+.6});tl.from('#s{i} aside>*',{{opacity:0,duration:.7,stagger:.5,ease:'sine.out'}},{t+1});\n"
    elif typ=='recap':js+="tl.from('#s5 .recap-card',{opacity:0,duration:.8,stagger:5.5,ease:'power2.out'},59);\n"
    elif typ=='stock':
        js+=f"tl.from('#s{i} .stock-proof',{{opacity:0,duration:.9,ease:'sine.out'}},{t+1});tl.from('#s{i} .pick-checks>div',{{opacity:0,duration:.8,stagger:10,ease:'power2.out'}},{t+2});tl.from('#s{i} .stock-pills>span',{{opacity:0,duration:.7,stagger:2,ease:'power1.out'}},{t+30});\n"
    elif typ=='packing':
        js+=f"tl.from('#s{i} .packing-photo',{{opacity:0,duration:.9,ease:'sine.out'}},{t+1});tl.from('#s{i} .pack-step',{{opacity:0,duration:.7,stagger:6,ease:'power2.out'}},{t+2});tl.from('#s{i} .packing-copy .small-card',{{opacity:0,duration:.8,ease:'power1.out'}},{t+25});tl.from('#s{i} .transfer',{{opacity:0,duration:.8,ease:'sine.out'}},{t+30});\n"
    elif typ=='codes':js+=f"tl.from('#s{i} .code-card',{{opacity:0,duration:.8,stagger:1,ease:'power2.out'}},{t+1});tl.from('#s{i} .next',{{opacity:0,duration:.8,ease:'power1.out'}},{t+8});\n"
    if typ=='ghn':js+=f"tl.from('#s{i} .ghn-fields>div',{{opacity:0,duration:.8,stagger:5,ease:'power1.out'}},{t+5});\n"

body+='<video id="selection" class="clip screen-video" data-start="0" data-duration="12.65" data-track-index="30" src="assets/selection.mp4" muted playsinline preload="auto"></video><video id="checkout" class="clip screen-video checkout-video" data-start="12" data-duration="31.65" data-track-index="31" src="assets/checkout-safe.mp4" muted playsinline preload="auto"></video>'
js+="tl.from('#checkout',{opacity:0,duration:.6,ease:'sine.inOut'},12);window.__timelines.main=tl;"
html='<!doctype html><html lang="vi"><head><meta charset="utf-8"><script src="assets/gsap.min.js"></script><style>'+css+'</style></head><body><main id="main" data-composition-id="main" data-start="0" data-duration="240" data-width="3840" data-height="2160" data-fps="30">'+body+'</main><script>'+js+'</script></body></html>'
(p/'index.html').write_text(html)
(p/'storyboard.json').write_text(json.dumps([{'start':s['start'],'end':s['start']+s['duration'],'type':s['type'],'title':re.search(r'<h1>(.*?)</h1>',s['html']).group(1)} for s in scenes],ensure_ascii=False,indent=2)+'\n')
(p/'meta.json').write_text(json.dumps({'id':'lth-style-doan5-v2','name':'LTH Style — Đoạn 5 v2: Đặt hàng và xử lý đơn','width':3840,'height':2160,'fps':30,'duration':240},ensure_ascii=False,indent=2)+'\n')
