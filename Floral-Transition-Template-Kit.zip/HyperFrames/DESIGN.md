# One arrangement / white editorial transition template

Create a reusable demonstration for the user to follow in CapCut, using the already accessible red and white Morri Concept flower arrangement. The newly uploaded C5308/C5310/C5314 files are not used. Match the reference's white canvas, inset portrait, stacked horizontal windows, landscape detail and restrained focus transitions. Same extracted reference music; total length 12.582358 seconds; 1080 × 1920 at 60 fps. Adapt the ending to Morri Concept. Keep the final white brand card through the audio endpoint.

Palette: canvas #FAFAFA; text #242422; secondary type #66635E; photographic crimson #A3122D and orchid ivory #F0E9DD remain native footage colors. No global color treatment. Lora for the quiet brand wordmark; DejaVu Sans for small editorial captions.

Measured visual cuts: 1.375, 2.916667, 4.958333, 7.083333, 8.166667, 9.5 seconds. Teaser-to-brand handoff at 10.5 seconds. Use short 0.22-second blur crossfades around the first six cut points, plus gentle 0.28-second text-card transition. Transitions use documented scene-container CSS blur, not permanent filters on footage. Media has been cropped/slowed with FFmpeg into local assets.

Build the final layouts first. Scene content is a full-canvas flex column. Opening portrait: 760 × 1270; second portrait: 880 × 1250; split: 960 × 1250, two equal panes with 10 px white gutter; horizontal macro: 984 × 670; final hero: 948 × 1515. Large untextured margins. Normal video frames use object-fit cover. Subtle 1–3% scale drift only. Protect edges through crop safety margins.

Do not add gold, glitter, snow, 3D flips, exaggerated zoom, stock assets, large captions or unrelated source footage. The guide is a readable reference sheet and CapCut recipe, separate from the clean demonstration video. It is not a native CapCut project or published CapCut template.
