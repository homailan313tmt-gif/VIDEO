# Đoạn 2 — Quản lý sản phẩm

Nhóm 11 · Lớp 49K22.4 · LTH Style.

120 giây · 3840 × 2160 · 16:9 · 30 fps · Không lời thoại, không âm thanh. Phong cách burgundy và kem, chuyển cảnh fade nhẹ; không quét ngang.

Đã bỏ phần nhóm sản phẩm theo yêu cầu. Chỉ dùng clip danh sách và chi tiết sản phẩm được cung cấp. Cảnh tồn kho không nằm trong video này.

## Nội dung
- 00:00–00:20: Danh sách 6 sản phẩm chính.
- 00:20–00:55: Tên, mô tả và hình ảnh áo 2 dây viền cổ phối ren Style Y2K.
- 00:55–01:25: Biến thể màu Trắng, Xám, Nâu, Đen.
- 01:25–01:45: Bốn SKU tương ứng với bốn màu.
- 01:45–02:00: Giá 69.000đ trên Haravan, dẫn sang quản lý tồn kho.

Đây là Đoạn 2 riêng; khi ghép sau Đoạn 1 sẽ tương ứng mốc 01:00–03:00.

Clip màn hình nguồn được quay ở 1920×1080; đầu ra và chữ/infographic ở 4K. Đã cắt thanh trình duyệt, làm chậm thao tác để đọc và giữ khung hình bảng biến thể tại phần giải thích SKU/giá. Không thêm minh chứng chỉnh sửa/lưu sản phẩm hoặc đối chiếu website khi clip chưa thể hiện các bước đó.

## Chỉnh sửa và dựng lại
Node.js 22+, FFmpeg và Chromium. Dùng HyperFrames 0.9.38 (ghim trong package.json).

```bash
npm run check
npm run render -- --output doan2.mp4 --fps 30 --quality high
```

Các clip đã cắt/chỉnh nhịp và đã loại âm thanh nằm trong assets/. Bản ghi nguồn đầy đủ không nằm trong gói dự án. index.html là composition có timeline GSAP seek được. build.py tái tạo HTML.
