# LTH Style — Đoạn 2
## Style Prompt
Infographic 2D cùng Đoạn 1, kết hợp video màn hình Haravan thật. Burgundy #800020, kem #FFF8EC, chữ #302327, nền thẻ #EEDDE1, đường kẻ #DAC5C8. Be Vietnam Pro. Khung 3840×2160, 30 fps, 120 giây. Không lời thoại, không âm thanh. Chuyển cảnh fade 0.6 giây, không wipe hoặc trượt ngang.
## Layout
Lề 160px, tiêu đề 112px, nội dung 54–64px, chữ phụ 40px. Video nằm bên trái rộng 2440px, thẻ giải thích bên phải rộng 940px. Giữ ảnh phần mềm đúng dữ liệu, cắt thanh trình duyệt để dễ xem.
## Constraints
Không có cảnh nhóm sản phẩm. Không đưa cảnh tồn kho vào đoạn này. Không giả thao tác lưu/chỉnh sửa hoặc đối chiếu website vì tư liệu chưa thể hiện. Không chọn một biến thể làm đơn hàng khi chưa có quyết định của người dùng. Phân biệt sản phẩm chính với bốn biến thể theo màu.
