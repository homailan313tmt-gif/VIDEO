# Đoạn 5 — Khách đặt và xử lý đơn hàng

Nhóm 11 · Lớp 49K22.4 · LTH Style.

240 giây · 3840×2160 · 16:9 · 30fps · Không lời thoại, không âm thanh. Burgundy #800020 và kem #FFF8EC. Chuyển cảnh fade 0.6 giây; không wipe, không trượt ngang. Không ghi chú hoặc số thứ tự ở chân cảnh.

## Nội dung
- 00:00–00:40: Website, áo 2 dây màu Trắng, SKU LTH-A2D-REN-001-TR-FS, giá 69.000đ, số lượng 1.
- 00:40–01:20: Sơ đồ minh họa kiểm tra giỏ hàng, thông tin giao nhận và thanh toán.
- 01:20–02:00: Đơn demo #10030 trên Haravan: tổng 84.000đ, Đã thanh toán, Chưa giao hàng.
- 02:00–02:40: Thông tin còn tồn 2 trong đơn và sơ đồ minh họa soạn, kiểm hàng.
- 02:40–03:15: Ảnh đóng gói demo đã cung cấp trước đó và quy trình kiểm tra kiện.
- 03:15–03:45: Vận đơn GHN GYENQLUW trong bản demo: COD 0đ, 200g, 1 sản phẩm, cước 16.500đ do người nhận thanh toán, trạng thái Chờ lấy hàng.
- 03:45–04:00: Phân biệt SKU, mã đơn Haravan, mã vận đơn GHN; dẫn sang tracking, giao hàng và COD.

Phần này tương ứng 06:00–10:00 khi ghép sau bốn đoạn trước.

## Nguồn và chỉnh sửa demo
Nguồn mới từ đoạn 5.zip: video website và ảnh đơn Haravan #10030. Dùng bổ sung ảnh vận đơn GHN cũ trong ZIP Ngọc Thịnh và ảnh đóng gói demo từ ZIP trước.

Theo yêu cầu người dùng, thay giá trị COD trong cảnh GHN từ 84.000đ thành 0đ, và thay “3 phút trước” ở thời gian Haravan thành 11/11/2026 17:38, theo mốc tạo đơn ở tracking GHN cũ. Các thay đổi này là lớp chữ trong composition; các cảnh tương ứng hiển thị nhãn Minh họa demo. Chúng không phải bản chụp chứng từ gốc sau chỉnh sửa nghiệp vụ trong phần mềm.

Phần checkout, soạn và kiểm hàng dùng sơ đồ minh họa quy trình; tư liệu không có clip thao tác checkout thành công, tạo vận đơn hoặc kiểm đếm áo ngoài đời. Không dựng giao diện giả để khẳng định đã thực hiện các bước đó. Clip website đã bỏ phần cuộn không liên quan và hộp thoại trình duyệt không phản hồi; nhịp clip được làm chậm để đọc.

## Thông tin riêng tư
Chỉ blur 4 số giữa số điện thoại, giữ 3 số đầu và 3 số cuối; chỉ blur số nhà, giữ tên đường và khu vực. Ảnh đưa vào gói dự án đã blur cố định, không chứa bản gốc chưa xử lý. Không có chữ báo đã che trên video.

## Dựng lại
Node.js 22+, FFmpeg, Chromium. HyperFrames ghim 0.9.38.

```bash
npm run check
npm run render -- --output doan5.mp4 --fps 30 --quality high
```

index.html là composition, build.py tái tạo HTML. assets/ chứa clip website đã chọn và tắt âm thanh, ảnh có blur, ảnh đóng gói demo, logo GHN và font. Không bao gồm bản ghi gốc có âm thanh hoặc ảnh gốc chưa blur.
