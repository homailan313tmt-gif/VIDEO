# LTH Style — Đoạn 5
## Style
Infographic 2D và tư liệu website/Haravan/GHN. Burgundy #800020, kem #FFF8EC, chữ #302327, thẻ #EEDDE1, đường kẻ #DAC5C8. Be Vietnam Pro. 3840×2160, 30fps, 240 giây. Không lời thoại, không âm thanh. Fade 0.6 giây; không wipe, không trượt ngang. Không ghi chú hoặc số thứ tự chân cảnh.
## Evidence and demo edits
Website: áo 2 dây màu Trắng, SKU LTH-A2D-REN-001-TR-FS, giá 69.000đ, số lượng 1. Haravan: #10030, tổng 84.000đ, Đã thanh toán, Chưa giao hàng, còn tồn 2 tại LTH Style Đà Nẵng. GHN: GYENQLUW, 200g, 1 sản phẩm, cước 16.500đ do người nhận thanh toán, Chờ lấy hàng. Theo yêu cầu người dùng, chỉnh COD GHN thành 0đ và thời gian tạo Haravan thành 11/11/2026 17:38 theo tracking cũ. Các cảnh chỉnh dữ liệu hiển thị nhãn Minh họa demo trong nội dung, không coi đó là chứng từ gốc. Phần checkout, soạn và kiểm hàng là sơ đồ minh họa quy trình vì không có clip thao tác đầy đủ.
## Privacy
Blur 4 chữ số giữa số điện thoại, giữ 3 số đầu và 3 số cuối. Blur số nhà, giữ tên đường và khu vực. Không có chữ đã che, không khung che; dữ liệu blur được xử lý cố định trước khi nhập composition. Không đưa ảnh API/token hoặc bản gốc có số điện thoại/địa chỉ đầy đủ vào gói dự án.
