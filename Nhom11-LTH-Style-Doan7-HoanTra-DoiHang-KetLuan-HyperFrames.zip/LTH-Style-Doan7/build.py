from pathlib import Path
import json

p = Path(__file__).parent

css = r'''
@font-face{font-family:BeVN;src:url(assets/fonts/BeVietnamPro-Regular.ttf);font-weight:400;font-display:block}
@font-face{font-family:BeVN;src:url(assets/fonts/BeVietnamPro-Black.ttf);font-weight:800 900;font-display:block}
:root{--b:#800020;--c:#fff8ec;--ink:#302327;--p:#eedde1;--line:#dac5c8;--muted:#73505a}
*{box-sizing:border-box;margin:0;padding:0}html,body,#main{width:3840px;height:2160px;overflow:hidden;background:var(--c);font-family:BeVN,sans-serif;color:var(--ink)}
#main{position:relative;font-variant-numeric:tabular-nums}.scene{position:absolute;inset:0;background:var(--c)}
.scene-content{width:100%;height:100%;padding:110px 160px 100px;display:flex;flex-direction:column;gap:45px}
.top{display:flex;justify-content:space-between;border-bottom:2px solid var(--line);padding-bottom:32px;color:var(--b);font-size:36px;font-weight:800;letter-spacing:4px;flex-shrink:0}
.heading{display:flex;flex-direction:column;gap:14px;flex-shrink:0}.kicker{font-size:38px;letter-spacing:4px;font-weight:800;color:var(--b)}
h1{font-size:112px;font-weight:900;color:var(--b);letter-spacing:-4px;line-height:1.2}.heading>p{font-size:54px;color:var(--muted)}
.body{display:flex;gap:110px;flex:1;min-height:0;align-items:center}.photo{width:1090px;height:1450px;border:3px solid var(--b);border-radius:28px;overflow:hidden;background:white;box-shadow:18px 18px 0 var(--p);flex-shrink:0}.photo>img{display:block;width:100%;height:100%;object-fit:cover}
.receive-copy{flex:1;display:flex;flex-direction:column;gap:35px}.receive-copy h2{font-size:103px;color:var(--b);font-weight:900;letter-spacing:-3px;line-height:1.3;max-width:2050px}.shipment{display:flex;gap:40px;align-items:center;padding:35px 0;border-bottom:2px solid var(--line)}.shipment img{width:150px;height:150px;border-radius:22px}.shipment>div{display:flex;flex-direction:column;gap:16px}.shipment small{font-size:37px;letter-spacing:4px;color:var(--muted)}.shipment strong{font-size:122px;line-height:1.1;color:var(--b);font-weight:900;letter-spacing:-4px}
.check{display:flex;gap:35px;align-items:center;padding:25px 0;border-bottom:2px solid var(--line)}.check b{width:80px;height:80px;border:3px solid var(--b);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:45px;color:var(--b);flex-shrink:0}.check p{font-size:65px;line-height:1.5}.receive-note{font-size:57px;line-height:1.6;background:var(--p);color:var(--b);padding:32px 40px;border-radius:24px}
.verify-grid{display:grid;grid-template-columns:1fr 1fr;gap:55px;flex:1;min-height:0;align-content:center}.verify-card{height:610px;padding:50px 60px;background:var(--p);border:2px solid var(--line);border-radius:28px;display:flex;flex-direction:column;gap:30px}.verify-card small{font-size:40px;letter-spacing:3px;color:var(--muted);font-weight:800}.verify-card h2{font-size:102px;color:var(--b);letter-spacing:-3px;line-height:1.3}.verify-card .sku{font-size:70px;letter-spacing:-2px;white-space:nowrap}.verify-card p{font-size:58px;line-height:1.6;max-width:1500px}.verify-card.dark{background:var(--b);color:var(--c);border-color:var(--b)}.verify-card.dark small,.verify-card.dark h2{color:var(--c)}
.process{display:flex;flex-direction:column;gap:65px;flex:1;min-height:0;justify-content:center}.flow{display:flex;align-items:center;gap:25px;justify-content:space-between}.step{width:760px;height:900px;border:2px solid var(--line);border-radius:28px;background:var(--p);padding:48px 42px;display:flex;flex-direction:column;gap:42px;flex-shrink:0}.number{width:115px;height:115px;border:3px solid var(--b);border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--b);font-size:57px;font-weight:900;flex-shrink:0}.step h2{font-size:80px;color:var(--b);line-height:1.35;letter-spacing:-2px;min-height:215px}.step p{font-size:56px;line-height:1.65}.connector{font-size:95px;color:var(--b);flex-shrink:0;width:95px;text-align:center}.step.last{background:var(--b);border-color:var(--b);color:var(--c)}.step.last h2,.step.last .number{color:var(--c);border-color:var(--c)}
.principle{display:flex;gap:40px;align-items:center;padding:45px 55px;border:2px solid var(--b);border-radius:25px;background:var(--c);color:var(--b);font-size:65px;font-weight:800;line-height:1.45}.principle b{font-size:77px;flex-shrink:0}.failed .step{width:1000px;height:800px;padding:55px}.failed .step h2{font-size:89px;min-height:230px}.failed .step p{font-size:60px}.failed .connector{width:120px;font-size:110px}
.exchange .step{width:605px;height:930px;padding:40px 32px;gap:34px}.exchange .number{width:100px;height:100px;font-size:52px}.exchange .step h2{font-size:69px;min-height:280px;line-height:1.4;letter-spacing:-1.5px}.exchange .step p{font-size:55px;line-height:1.65}.exchange .connector{width:65px;font-size:75px}.exchange .flow{gap:20px}
.accounting{display:flex;flex-direction:column;gap:65px;flex:1;min-height:0;justify-content:center}.entry-grid{display:flex;gap:70px}.entry{flex:1;height:800px;padding:55px 65px;border:2px solid var(--line);border-radius:28px;background:var(--p);display:flex;flex-direction:column;gap:36px}.entry small{font-size:42px;letter-spacing:4px;color:var(--muted);font-weight:800}.entry h2{font-size:95px;color:var(--b);line-height:1.35;letter-spacing:-3px}.entry p{font-size:61px;line-height:1.6}.entry .entry-result{margin-top:auto;font-size:65px;color:var(--b);font-weight:800;padding-top:30px;border-top:2px solid var(--line)}.entry.dark{background:var(--b);border-color:var(--b);color:var(--c)}.entry.dark small,.entry.dark h2,.entry.dark .entry-result{color:var(--c)}.entry.dark .entry-result{border-top-color:#ad5c70}.cost-grid{display:flex;gap:70px}.cost{flex:1;padding:38px 50px;border:2px solid var(--line);border-radius:24px;display:flex;flex-direction:column;gap:20px}.cost small{font-size:39px;letter-spacing:3px;color:var(--muted);font-weight:800}.cost strong{font-size:67px;line-height:1.45;color:var(--b)}
.summary{flex:1;min-height:0;display:flex;flex-direction:column;gap:40px;justify-content:center}.summary-grid{display:grid;grid-template-columns:1fr 1fr;gap:45px}.evidence{height:590px;border:3px solid var(--b);border-radius:26px;overflow:hidden;background:white;box-shadow:13px 13px 0 var(--p);display:flex;flex-direction:column;flex-shrink:0}.evidence-img{height:350px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:white;overflow:hidden}.evidence-img img{width:100%;height:100%;object-fit:contain;display:block}.evidence-copy{display:flex;flex-direction:column;gap:10px;padding:28px 42px;background:var(--p);flex:1;min-height:0}.evidence h2{font-size:78px;color:var(--b);letter-spacing:-2px;line-height:1.25}.evidence p{font-size:48px;color:var(--ink);line-height:1.4}.tagline{font-size:66px;color:var(--b);font-weight:800;line-height:1.45;text-align:center;padding:10px 0}
.outro{background:var(--b);color:var(--c)}.outro .scene-content{align-items:center;justify-content:center;gap:65px;text-align:center;padding:150px 160px}.outro .eyebrow{font-size:50px;letter-spacing:7px}.outro h1{font-size:320px;color:var(--c);letter-spacing:-12px;line-height:1.15}.outro .group{font-size:72px;letter-spacing:5px;font-weight:800}.outro .thanks{font-size:142px;line-height:1.4;letter-spacing:-4px;font-weight:900;max-width:3500px}.outro .closing-line{width:1100px;height:3px;background:#c68d9b;margin:15px 0}.outro .closing-tag{font-size:62px;line-height:1.5;max-width:3350px}
'''

def step(n, title, text, last=False):
    return f'<div class="step step-{n}'+(' last' if last else '')+f'"><div class="number">{n:02d}</div><h2>{title}</h2><p>{text}</p></div>'

def flow(items):
    return '<div class="flow">'+('<span class="connector">→</span>'.join(items))+'</div>'

contents=[]
contents.append(('Nhận hàng và kiểm tra kiện','Đối chiếu kiện với thông tin đơn đã đặt',r'''
<div class="body"><div class="photo"><img src="assets/parcel-safe.png" alt="Ảnh kiện hàng có phiếu gửi trong dự án"/></div><div class="receive-copy">
<h2>Đối chiếu phiếu gửi và bao gói</h2><div class="shipment"><img src="assets/ghn.png" alt="GHN"/><div><small>MÃ VẬN ĐƠN TRÊN PHIẾU</small><strong>GYENL6TA</strong></div></div>
<div class="check r1"><b>✓</b><p>Kiểm tra kiện và niêm phong</p></div><div class="check r2"><b>✓</b><p>Đối chiếu thông tin phiếu gửi</p></div><div class="check r3"><b>✓</b><p>Lưu ảnh cùng thông tin đơn</p></div><div class="receive-note">Tiếp tục kiểm tra sản phẩm sau khi mở gói.</div>
</div></div>'''))

contents.append(('Đối chiếu sản phẩm sau mở gói','Kiểm tra theo thông tin sản phẩm trong đơn',r'''
<div class="verify-grid"><div class="verify-card v0"><small>SKU SẢN PHẨM</small><h2 class="sku">LTH-A2D-REN-001-TR-FS</h2><p>Đối chiếu đúng mã biến thể đã đặt.</p></div>
<div class="verify-card v1"><small>QUY CÁCH</small><h2>Trắng · Free Size</h2><p>Kiểm tra màu sắc và kích cỡ.</p></div>
<div class="verify-card v2"><small>SỐ LƯỢNG TRONG ĐƠN</small><h2>1 sản phẩm</h2><p>Đếm và đối chiếu số lượng nhận.</p></div>
<div class="verify-card dark v3"><small>TÌNH TRẠNG SẢN PHẨM</small><h2>Kiểm tra sau nhận</h2><p>Quan sát vải, đường may và tình trạng hàng.</p></div></div>'''))

contents.append(('Quy trình hoàn trả','Khi khách phát sinh yêu cầu trả hàng','<div class="process returns">'+flow([
step(1,'Tiếp nhận yêu cầu','Ghi nhận lý do và thông tin đơn.'),
step(2,'Kiểm tra điều kiện','Đối chiếu chính sách đã công bố.'),
step(3,'Nhận và kiểm hàng','Kiểm tra quy cách, số lượng và tình trạng.'),
step(4,'Cập nhật và hoàn tiền','Nhập lại hàng đủ điều kiện; xử lý hoàn tiền.',True)
])+r'<div class="principle"><b>✓</b><span>Kiểm tra hàng trước khi quyết định nhập lại tồn.</span></div></div>'))

contents.append(('Trường hợp giao không thành công','Theo dõi chiều hoàn về cửa hàng','<div class="process failed">'+flow([
step(1,'Giao không thành công','Theo dõi trạng thái trên vận đơn.'),
step(2,'Theo dõi kiện hoàn','Ghi nhận hành trình chuyển hoàn.'),
step(3,'Nhận và kiểm tra','Đối chiếu kiện, sản phẩm và tình trạng.',True)
])+r'<div class="principle"><b>✓</b><span>Nhận và kiểm tra kiện trước khi cập nhật tồn.</span></div></div>'))

contents.append(('Quy trình đổi hàng','Kiểm tra tồn của đúng biến thể khách muốn đổi','<div class="process exchange">'+flow([
step(1,'Tiếp nhận yêu cầu','Xác nhận quy cách khách muốn đổi.'),
step(2,'Kiểm tra điều kiện và tồn','Đối chiếu chính sách và đúng SKU thay thế.'),
step(3,'Nhận hàng cũ','Tiếp nhận sản phẩm khách gửi về.'),
step(4,'Kiểm tra hàng','Đánh giá tình trạng trước khi xử lý.'),
step(5,'Gửi hàng thay thế','Soạn và giao đúng biến thể đã thống nhất.',True)
])+r'<div class="principle"><b>✓</b><span>Kiểm tra hàng cũ trước khi gửi hàng thay thế.</span></div></div>'))

contents.append(('Ghi nhận nghiệp vụ đổi hàng','Thống nhất chi phí và ghi nhận riêng nhập, xuất',r'''
<div class="accounting"><div class="entry-grid"><div class="entry old"><small>HÀNG CŨ · NGHIỆP VỤ NHẬP</small><h2>Nhận và kiểm hàng</h2><p>Đánh giá tình trạng sản phẩm được gửi về.</p><div class="entry-result">Nhập lại khi đủ điều kiện</div></div>
<div class="entry dark new"><small>HÀNG THAY THẾ · NGHIỆP VỤ XUẤT</small><h2>Kiểm tồn đúng SKU</h2><p>Soạn đúng màu, kích cỡ và số lượng.</p><div class="entry-result">Ghi nhận xuất và gửi hàng</div></div></div>
<div class="cost-grid"><div class="cost price"><small>CHÊNH LỆCH GIÁ</small><strong>Thống nhất với khách</strong></div><div class="cost shipping"><small>PHÍ VẬN CHUYỂN</small><strong>Xác nhận trước khi xử lý</strong></div></div></div>'''))

contents.append(('Theo dõi xuyên suốt hành trình','Sản phẩm → Tồn kho → Đơn hàng → Giao nhận',r'''
<div class="summary"><div class="summary-grid">
<div class="evidence q0"><div class="evidence-img"><img src="assets/products.png" alt="Biến thể sản phẩm trên Haravan"/></div><div class="evidence-copy"><h2>Sản phẩm</h2><p>Nhận diện đúng biến thể và SKU</p></div></div>
<div class="evidence q1"><div class="evidence-img"><img src="assets/inventory.png" alt="Các dòng biến thể và tồn trên Haravan"/></div><div class="evidence-copy"><h2>Tồn kho</h2><p>Kiểm tra đúng SKU tại đúng kho</p></div></div>
<div class="evidence q2"><div class="evidence-img"><img src="assets/order-item-safe.png" alt="Dòng sản phẩm trong đơn hàng"/></div><div class="evidence-copy"><h2>Đơn hàng</h2><p>Đối chiếu quy cách và số lượng</p></div></div>
<div class="evidence q3"><div class="evidence-img"><img src="assets/delivered-safe.png" alt="Trạng thái giao hàng trên GHN"/></div><div class="evidence-copy"><h2>Giao nhận</h2><p>Theo dõi trạng thái vận chuyển</p></div></div>
</div><div class="tagline">Đúng sản phẩm · Đúng quy cách · Theo dõi xuyên suốt</div></div>'''))

contents.append(('','','''<div class="eyebrow">DỰ ÁN LOGISTICS ĐIỆN TỬ</div><h1>LTH Style</h1><div class="group">NHÓM 11 · LỚP 49K22.4</div><div class="closing-line"></div><div class="thanks">Cảm ơn thầy cô và các bạn!</div><div class="closing-tag">Hậu cần đầu ra trong thương mại điện tử</div>'''))

starts=[0,15,30,50,65,85,100,112]
ends=[15,30,50,65,85,100,112,120]
scenes=[]
for i,(title,sub,body) in enumerate(contents):
    duration=ends[i]-starts[i]+(.65 if i<7 else 0)
    top='' if i==7 else f'<div class="top"><span>NHÓM 11 · LỚP 49K22.4</span><span>ĐOẠN 07 · SAU GIAO HÀNG VÀ KẾT LUẬN</span></div><div class="heading"><div class="kicker">LTH STYLE · HẬU CẦN ĐẦU RA</div><h1>{title}</h1><p>{sub}</p></div>'
    scenes.append(f'<section id="s{i}" class="clip scene'+(' outro' if i==7 else '')+f'" style="z-index:{i*10}" data-start="{starts[i]}" data-duration="{duration}" data-track-index="{i+1}"><div class="scene-content" data-layout-allow-overlap data-hold="Khoảng dừng để đọc ảnh và từng bước xử lý">{top}{body}</div></section>')

js="window.__timelines=window.__timelines||{};const tl=gsap.timeline({paused:true});\n"
for i,t in enumerate(starts):
    if i:js+=f"tl.from('#s{i}',{{opacity:0,duration:.6,ease:'sine.inOut'}},{t});\n"
    if i<7:
        js+=f"tl.from('#s{i} .top',{{opacity:0,duration:.6,ease:'power1.out'}},{t+.12});\n"
        js+=f"tl.from('#s{i} .heading',{{opacity:0,duration:.75,ease:'sine.out'}},{t+.25});\n"
js+=r'''
tl.from('#s0 .photo',{opacity:0,duration:.9,ease:'power2.out'},.6);
tl.from('#s0 .receive-copy h2',{opacity:0,duration:.8,ease:'sine.out'},1);
tl.from('#s0 .shipment',{opacity:0,duration:.8,ease:'power1.out'},1.8);
tl.from('#s0 .r1',{opacity:0,duration:.8,ease:'power2.out'},3.5);
tl.from('#s0 .r2',{opacity:0,duration:.8,ease:'sine.out'},6.5);
tl.from('#s0 .r3',{opacity:0,duration:.8,ease:'power1.out'},9.5);
tl.from('#s0 .receive-note',{opacity:0,duration:.8,ease:'power2.out'},12);
tl.from('#s1 .v0',{opacity:0,duration:.8,ease:'power2.out'},16);
tl.from('#s1 .v1',{opacity:0,duration:.8,ease:'sine.out'},19);
tl.from('#s1 .v2',{opacity:0,duration:.8,ease:'power1.out'},22);
tl.from('#s1 .v3',{opacity:0,duration:.8,ease:'power2.out'},25);
tl.from('#s2 .step-1',{opacity:0,duration:.8,ease:'power2.out'},31);
tl.from('#s2 .step-2',{opacity:0,duration:.8,ease:'sine.out'},35);
tl.from('#s2 .step-3',{opacity:0,duration:.8,ease:'power1.out'},39);
tl.from('#s2 .step-4',{opacity:0,duration:.8,ease:'power2.out'},43);
tl.from('#s2 .connector',{opacity:0,duration:.7,stagger:4,ease:'sine.out'},34.8);
tl.from('#s2 .principle',{opacity:0,duration:.8,ease:'power1.out'},46);
tl.from('#s3 .step-1',{opacity:0,duration:.8,ease:'power2.out'},51);
tl.from('#s3 .step-2',{opacity:0,duration:.8,ease:'sine.out'},55);
tl.from('#s3 .step-3',{opacity:0,duration:.8,ease:'power1.out'},59);
tl.from('#s3 .connector',{opacity:0,duration:.7,stagger:4,ease:'sine.out'},54.8);
tl.from('#s3 .principle',{opacity:0,duration:.8,ease:'power2.out'},62);
tl.from('#s4 .step-1',{opacity:0,duration:.8,ease:'power2.out'},66);
tl.from('#s4 .step-2',{opacity:0,duration:.8,ease:'sine.out'},69);
tl.from('#s4 .step-3',{opacity:0,duration:.8,ease:'power1.out'},72);
tl.from('#s4 .step-4',{opacity:0,duration:.8,ease:'power2.out'},75);
tl.from('#s4 .step-5',{opacity:0,duration:.8,ease:'sine.out'},78);
tl.from('#s4 .connector',{opacity:0,duration:.7,stagger:3,ease:'power1.out'},68.8);
tl.from('#s4 .principle',{opacity:0,duration:.8,ease:'power2.out'},81.5);
tl.from('#s5 .old',{opacity:0,duration:.8,ease:'power2.out'},86);
tl.from('#s5 .new',{opacity:0,duration:.8,ease:'sine.out'},89);
tl.from('#s5 .price',{opacity:0,duration:.8,ease:'power1.out'},93);
tl.from('#s5 .shipping',{opacity:0,duration:.8,ease:'power2.out'},96);
tl.from('#s6 .evidence',{opacity:0,duration:.8,stagger:1.8,ease:'power2.out'},101);
tl.from('#s6 .tagline',{opacity:0,duration:.8,ease:'sine.out'},108.5);
tl.from('#s7 .eyebrow',{opacity:0,duration:.7,ease:'sine.out'},112.4);
tl.from('#s7 h1',{opacity:0,duration:.9,ease:'power2.out'},112.7);
tl.from('#s7 .group',{opacity:0,duration:.8,ease:'power1.out'},113.1);
tl.from('#s7 .closing-line',{opacity:0,duration:.8,ease:'sine.out'},113.5);
tl.from('#s7 .thanks',{opacity:0,duration:.8,ease:'power2.out'},114);
tl.from('#s7 .closing-tag',{opacity:0,duration:.8,ease:'power1.out'},115);
window.__timelines.main=tl;
'''

html='<!doctype html><html lang="vi"><head><meta charset="utf-8"><script src="assets/gsap.min.js"></script><style>'+css+'</style></head><body><main id="main" data-composition-id="main" data-start="0" data-duration="120" data-width="3840" data-height="2160" data-fps="30">'+''.join(scenes)+'</main><script>'+js+'</script></body></html>'
(p/'index.html').write_text(html)
(p/'meta.json').write_text(json.dumps({'id':'lth-style-doan7','name':'LTH Style — Đoạn 7: Sau giao hàng và kết luận','width':3840,'height':2160,'fps':30,'duration':120},ensure_ascii=False,indent=2)+'\n')
pkg=json.loads((p/'package.json').read_text());pkg['name']='lth-part7';(p/'package.json').write_text(json.dumps(pkg,indent=2)+'\n')
(p/'storyboard.json').write_text(json.dumps([{'start':starts[i],'end':ends[i],'title':c[0] or 'LTH Style — Cảm ơn thầy cô và các bạn!','subtitle':c[1]} for i,c in enumerate(contents)],ensure_ascii=False,indent=2)+'\n')
