# LTH Style — Đoạn 7

## Style

Đồng bộ các đoạn trước: infographic 2D, 16:9, 3840×2160, 30fps, 120 giây. Burgundy #800020, kem #FFF8EC, chữ #302327, chữ phụ #73505A, thẻ #EEDDE1, đường kẻ #DAC5C8. Be Vietnam Pro Regular 400 và Black 900 từ font cục bộ. Fade 0.6 giây giữa cảnh và fade nhẹ khi hiện từng bước; không trượt ngang, không wipe. Không lời thoại và không âm thanh. Không ghi chú, đánh số chân cảnh hay chữ báo đã che.

## Content

- 0–15s: ảnh kiện hiện có, phiếu gửi và các bước đối chiếu khi nhận.
- 15–30s: infographic kiểm tra sau mở gói: SKU, quy cách, số lượng và tình trạng; dùng thông tin sản phẩm trong đơn làm dữ liệu tham chiếu.
- 30–50s: yêu cầu trả hàng → kiểm tra điều kiện → nhận và kiểm hàng → cập nhật tồn và hoàn tiền.
- 50–65s: giao không thành công → theo dõi kiện hoàn → nhận và kiểm tra; đánh giá hàng trước khi cập nhật tồn.
- 65–85s: yêu cầu đổi → kiểm tra điều kiện và tồn → nhận hàng cũ → kiểm tra → gửi biến thể thay thế.
- 85–100s: ghi nhận nhập hàng cũ đủ điều kiện, xuất biến thể mới; thống nhất chênh lệch giá và phí giao.
- 100–112s: bốn khung Sản phẩm → Tồn kho → Đơn hàng → Giao nhận.
- 112–120s: LTH Style, NHÓM 11 · LỚP 49K22.4, lời cảm ơn.

## Provenance

Người dùng chọn “Dùng ảnh hiện có và infographic”. Chưa có ảnh mở gói hoặc ảnh kiểm sản phẩm sau nhận; không tạo ảnh giả hay ghi ảnh hiện có là bằng chứng khách mở gói. Ảnh kiện được dùng đúng vai trò ảnh kiện trong dự án. Hoàn trả và đổi hàng dùng cách diễn đạt quy trình, điều kiện, không khẳng định đã có đơn hoàn/đổi thực tế. Không tự đặt mã SKU thay thế, kích cỡ mới, tiền hoàn hoặc chính sách cụ thể.

## Privacy

Dùng lại ảnh đã blur số nhà và một phần số điện thoại từ các đoạn trước. Chỉ đưa ảnh đã xử lý vào source, trừ ảnh bàn giao gốc không có các trường thông tin nhận hàng cần ẩn. Không có nhãn “đã che”, khối che màu hay cảnh báo trên video.

## What NOT to Do

- Không thêm lời đọc, avatar hoặc danh sách thành viên.
- Không dùng hiệu ứng chuyển từ trái sang phải.
- Không gọi ảnh kiện là ảnh sản phẩm đã được mở kiểm sau giao.
- Không khẳng định phát sinh hoàn trả, đổi hàng hay hoàn tiền thực tế.
- Không trình bày thông tin phần mềm được dựng lại như màn hình gốc.
