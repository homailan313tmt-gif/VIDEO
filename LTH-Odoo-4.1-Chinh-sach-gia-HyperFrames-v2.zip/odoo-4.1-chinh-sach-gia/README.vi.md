# LTH Style · 4.1 · Chính sách giá

Đoạn riêng **26 giây, 3840×2160, 16:9, 30 fps**, dùng để chèn sau phần sản phẩm/biến thể và trước 4.2.

- Giữ trọn clip gốc `4.1.4.mp4`: 563 khung hình, 18,7667 giây, tốc độ 1×.
- Thêm 217 khung hình giữ nguyên ảnh cuối, để đủ thời gian đọc ví dụ; tổng 780 frame.
- Giữ toàn bộ giao diện Odoo, không crop, zoom, vẽ lại hoặc thay số liệu. Phần chú thích nằm bên ngoài màn hình thao tác.
- Thể hiện sáu mẫu, 48 biến thể; chính sách cuối mùa cho 18 biến thể, giảm chọn lọc 10–20%; thời gian 01/11–30/11/2026.
- Ví dụ quần ống rộng nữ Nâu/M: giá niêm yết 299.000đ, chiết khấu 20%, phép tính 239.200đ. Giá tính được ghi rõ ở phần chú thích, không giả làm ô giá giao dịch trong Odoo.
- Bản này **chưa có voice 4.1.4**. Không tạo giọng tổng hợp hoặc thêm nhạc. Khi có bản thu, có thể thêm audio trên track riêng và căn theo mốc.

Phong cách nền sáng, tím Odoo, Be Vietnam Pro; không chuyển cảnh hoặc thanh timeline chạy dưới.

```bash
npm run check
npm run render -- --output renders/LTH-Odoo-4.1-Chinh-sach-gia-4K-26s-v2.mp4
```

Nguồn và các phép đối chiếu nằm trong `source-edits.json`. Đây là clip bổ sung độc lập; bản thực hành 5:59 trước đó không bị ghi đè. Nếu chèn đủ 26 giây vào bản trước, phần thao tác và thẻ mục trước 4.5 dài khoảng 5:24,6, vẫn dưới 6 phút; tổng video gồm báo cáo/kết khi đó khoảng 6:25,1.

Bản sửa theo yêu cầu: nhãn hiển thị **4.1**, tiêu đề **Chính sách giá và bảng giá cuối mùa**. Giữ nguyên nội dung, thời lượng và thao tác; tên clip nguồn vẫn là `4.1.4.mp4`.
