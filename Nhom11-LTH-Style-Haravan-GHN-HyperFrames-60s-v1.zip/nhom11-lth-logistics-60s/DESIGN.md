# LTH Style · Logistics điện tử · Nhóm 11

## Style Prompt
Infographic kỹ thuật rõ ràng, gần gũi và có chuyển động nhẹ. Kế thừa nền sáng, tím Odoo và Be Vietnam Pro của các đoạn trước; bổ sung màu beige của cửa hàng thời trang và cam GHN cho chặng vận chuyển. Cảnh chính là hình minh họa phẳng được vẽ vector, với con người, trang phục, máy tính và kiện hàng.

## Colors
- #FFFFFF: nền chính.
- #F6F2F6: nền tím nhạt.
- #714B67: nhận diện nhóm, cửa hàng và vận hành nội bộ.
- #29232A: nội dung chính.
- #625765: nội dung phụ.
- #EDE0D3 và #A77958: nền sản phẩm, quần áo beige.
- #BF4D20: GHN và chặng giao hàng (chữ đạt tương phản trên nền sáng).

## Typography
Be Vietnam Pro 400/900 cục bộ. Tiêu đề 68–100 px; nội dung 32–40 px; nhãn 28–32 px. Khung thiết kế 1920×1080; xuất 4K 3840×2160, 30 fps, đúng 60 giây.

## Timing
0–8 giới thiệu Nhóm 11; 8–18 LTH Style; 18–26 nội thành Đà Nẵng; 26–35 Haravan; 35–50 in-house kết hợp GHN; 50–60 dẫn vào thực hành.

## Motion
Nội dung vào cảnh nhẹ bằng opacity, y 12–28 px và scale 0.97–1; giữ chữ đủ lâu. Biểu tượng, chấm màu, kiện hàng và tuyến đường chuyển động để giải thích từng bước. Cảnh 6 kết bằng phóng to bước Đặt hàng. Không thanh timeline chạy dưới. Dùng cắt trực tiếp gọn theo sở thích đã duyệt, kèm biến đổi máy tính/cửa hàng trong cảnh khi cần.

## What NOT to Do
- Không giả ảnh minh họa là giao diện quản trị Haravan thật.
- Không thay đổi chữ hoặc chi tiết trong ảnh chụp được cung cấp.
- Bản đồ chỉ minh họa mạng lưới phục vụ, không vẽ ranh giới hành chính hoặc địa danh cụ thể ngoài Đà Nẵng.
- Không tạo số liệu kinh doanh, danh tính thành viên hoặc giá sản phẩm chưa được cung cấp.
- Không tạo giọng tổng hợp; để trống âm thanh theo cách làm đã thống nhất cho người dùng thu voice riêng.
