# Nhóm 11 · LTH Style · Logistics điện tử

Video infographic riêng, đúng **60 giây · 3840×2160 · 16:9 · 30 fps**. Phong cách nền sáng, tím Odoo, Be Vietnam Pro, chuyển động nhẹ. Không có voice hoặc nhạc; dành chỗ để người dùng ghép bản thu riêng.

| Mốc | Nội dung |
|---|---|
| 00:00–00:08 | Nhóm 11 · Lớp 49K22.4 · Dự án Logistics điện tử; các biểu tượng thành viên tập hợp quanh máy tính |
| 00:08–00:18 | LTH Style; áo, quần, váy và biến thể màu; sinh viên, nhân viên văn phòng |
| 00:18–00:26 | Mạng lưới phục vụ nội thành Đà Nẵng; kho, khách hàng và các kiện hàng trên tuyến |
| 00:26–00:35 | Haravan; website bán hàng và ba chức năng sản phẩm, tồn kho, đơn hàng |
| 00:35–00:50 | LTH Style thực hiện quản lý hàng, xác nhận đơn, soạn hàng, đóng gói; bàn giao cho GHN và giao đến khách |
| 00:50–01:00 | Đặt hàng → Xử lý → Vận chuyển → Nhận hàng; hoàn trả, đổi hàng; phóng vào Đặt hàng để nối thao tác thực tế |

## Ảnh website

Bản v1 hiện dùng **website bán hàng minh họa**, được ghi rõ trên màn hình. Ảnh người dùng gửi chỉ hiện trong tin nhắn, chưa có tệp ảnh gốc trong môi trường dựng. Không vẽ lại ảnh đó hoặc giả giao diện minh họa là giao diện Haravan thật. Khi có PNG/JPG gốc, đặt bản PNG giữ nguyên nội dung tại `assets/lth-style-website.png`, chạy `python build-source.py` rồi kiểm tra và render. Nếu ảnh gốc là JPG, chuyển container ảnh sang PNG không chỉnh sửa hình ảnh, hoặc sửa đường dẫn cho đúng phần mở rộng.

Bản đồ là sơ đồ mạng lưới minh họa, không thể hiện ranh giới hành chính. Nhân vật là biểu tượng đại diện, không phải danh sách hay chân dung thành viên thực tế. GHN được thể hiện bằng chữ và xe minh họa.

## Dựng lại

```bash
npm run check
npm run render -- --output renders/Nhom11-LTH-Style-Haravan-GHN-4K-60s-v1.mp4
```

HyperFrames được cố định ở 0.8.216. HTML, GSAP, phông và đồ họa vector được lưu cục bộ. Giấy phép phông nằm trong `assets/fonts/OFL.txt`.

Các cảnh cắt trực tiếp, chuyển động tiết chế theo sở thích đã duyệt; không có thanh timeline chạy dưới. Cảnh và thời lượng được khai báo trong `storyboard.json`. Bản này được tạo riêng, không ghi đè video Odoo hoặc intro/outro trước đó.

## Kiểm tra

`check.json`: không có lỗi runtime, bố cục, chuyển động hoặc tương phản. Cảnh báo `nested_structure_needs_subcomposition` là gợi ý chia nguồn thành tệp con: sáu cảnh được chủ ý giữ trong một HTML tự chứa để dễ chuyển giao. `film_silent` đúng với bản hình chờ voice riêng. Khung hình đã được xem tại các cảnh, bàn giao GHN và bước Đặt hàng cuối.
