# Nhóm 11 · outro · 3 giây · 4K

Video riêng, 3840 × 2160, 16:9, 30 fps, đúng 90 khung hình. Phông Be Vietnam Pro hỗ trợ tiếng Việt, nền sáng và tím Odoo. Chữ xuất hiện nhẹ trong 0,8 giây đầu rồi giữ rõ đến hết clip. Không âm thanh.

Thông tin: Nhóm 11 · Lớp 49K22.4 · DỰ ÁN NHÓM – E-LOGISTICS TRÊN ODOO.

```bash
npm run check
npm run render -- --output renders/Nhom11-Ket-thuc-Thay-Co-4K-3s-v2.mp4
```

Toàn bộ phông, GSAP và đồ họa SVG được lưu cục bộ trong dự án. Giấy phép phông: assets/fonts/OFL.txt.

Nội dung kết thúc: **CẢM ƠN THẦY CÔ ĐÃ THEO DÕI!**. Bản sửa chỉ đổi lời cảm ơn và rút thời lượng từ 5 còn 3 giây.
