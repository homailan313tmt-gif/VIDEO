# LTH Style — Đoạn 6
## Style
Infographic 2D và ảnh GHN, đồng bộ các đoạn trước. Burgundy #800020, kem #FFF8EC, chữ #302327, thẻ #EEDDE1, đường kẻ #DAC5C8. Be Vietnam Pro. 3840×2160, 30fps, 120 giây. Không lời thoại, không âm thanh. Fade 0.6 giây; không wipe, không trượt ngang. Không ghi chú, số thứ tự chân cảnh hoặc chữ báo đã che.
## Content
0–30s: ảnh kiện đã dán nhãn, phiếu gửi GYENL6TA, đối chiếu mã và giới thiệu khâu giao nhận.
30–75s: tracking, giữ nguyên năm mốc và tên trạng thái: Tạo đơn 11/11 17:38; Đang lấy hàng 12/11 16:29; Đang vận chuyển 13/11 08:04; Đang giao hàng 13/11 08:04; Giao hàng thành công 13/11 15:59.
75–100s: phóng trạng thái giao thành công, thời gian và ảnh kiện.
100–120s: COD 0đ trên phiếu; cước 16.500đ và người nhận thanh toán theo ảnh dự án đã chỉnh trước đó. Dẫn sang nhận hàng, hoàn trả và đổi hàng.
## Provenance
Ảnh tracking cũ không có mã vận đơn hiển thị; giữ nguyên mốc, không thêm mã vào bên trong ảnh tracking. Ảnh kiện và phiếu gửi mới thể hiện GYENL6TA, #10029, thu người nhận 0. Ảnh cước đã được chỉnh mã từ GYENQLUW thành GYENL6TA và COD từ 84.000 thành 0 theo yêu cầu người dùng; không gọi ảnh cước này là chứng từ gốc. Không khẳng định ảnh kiện là minh chứng bàn giao tận tay nhân viên vận chuyển. Không khẳng định có ảnh khách mở gói hoặc đã đối soát tiền.
## Privacy
Giữ số điện thoại đã ẩn sẵn trên phiếu. Blur số nhà ở phiếu, ảnh kiện và tracking; giữ tên đường, phường, thành phố. Bản dự án chỉ chứa ảnh đã xử lý, không chứa nguồn chưa blur.
