# LTH Style · Odoo · Bản 05 có lời đọc

Video: `LTH-Odoo-V1-den-Ket-4K-v5-Voice-5m59.mp4`.

- Thời lượng: **5:59,067**; phần thao tác và thẻ mục trước 4.5 kết thúc ở 4:58,567.
- Hình: **3840 × 2160, 16:9, 30 fps**, H.264. Hình được sao chép nguyên từ bản 04, không mã hóa lại.
- Âm thanh: AAC 48 kHz stereo, dùng hai file MP3 người dùng gửi; căn 64 câu vào 27 đoạn. Cắt tại khoảng nghỉ, cân âm lượng, giữ tốc độ giọng đọc **1×**. Không thêm nhạc hoặc giọng tổng hợp.
- Câu “đã thanh toán” và “còn hai mươi sáu chiếc” được đặt theo bằng chứng trên màn hình. Một câu báo cáo tổng quát nối qua cảnh Forecast để giữ tốc độ đọc gốc.
- Không thêm chuyển cảnh, thanh tiến độ hoặc thay đổi dữ liệu Odoo.

`assets/voice-narration.m4a` chứa toàn bộ tiếng đã căn vào bản 5:59. `voice-sync.json` lưu mốc trong bản ghi gốc và mốc đặt từng câu. `Loi-thuyet-minh.txt` là kịch bản tham chiếu.

Dự án HyperFrames tự chứa các tài nguyên. Với Node.js, Chromium và FFmpeg phù hợp:

```bash
npm run check
npx hyperframes@0.8.216 preview --background
npx hyperframes@0.8.216 render --fps 30 --resolution landscape-4k --quality high --crf 16 --video-frame-format png --output renders/LTH-Odoo-v5-voice.mp4
```

P00008 của quần khác P00006 của váy. Cảnh tạo RFQ P00008 ở 4.3.5 quay lại bước trước khi xác nhận đơn mua. V2 dùng váy đen, cỡ M; màn hình quy tắc của quần được chú thích riêng. Kết quả “đã giao 5, hiện còn 26” không được diễn giải thành biến động 31 → 26 khi chưa đủ bằng chứng. Ảnh báo cáo là ảnh tham chiếu từ clip thật.

Kết quả kiểm tra nằm trong `check.json` và `delivery-check.json`.
