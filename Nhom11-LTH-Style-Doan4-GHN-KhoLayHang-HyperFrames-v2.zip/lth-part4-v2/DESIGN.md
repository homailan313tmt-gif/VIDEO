# LTH Style — Đoạn 4
## Style Prompt
Infographic 2D và ảnh cấu hình thực tế, đồng bộ ba đoạn trước. Burgundy #800020, kem #FFF8EC, chữ #302327, nền thẻ #EEDDE1, đường kẻ #DAC5C8. Be Vietnam Pro. 3840×2160, 30fps, 60 giây. Không lời thoại, không âm thanh. Fade nhẹ 0.6 giây; không wipe, không trượt ngang.
## Layout
Lề 160px, tiêu đề 112px, nội dung 54–64px. Ảnh chứng minh bên trái, thẻ giải thích bên phải. Phóng vùng tài khoản kết nối ở giữa đoạn. Ba bước kiểm tra cuối đoạn có nhịp xuất hiện lần lượt.
## Evidence
Chọn đúng hai ảnh: Haravan có Giao Hàng Nhanh, trạng thái Đã kết nối; ảnh GHN có thông tin cửa hàng LTH Style Đà Nẵng. Chỉ dùng bản crop đã che số điện thoại và địa chỉ chi tiết cho ảnh GHN. Khu vực công khai: Ngũ Hành Sơn, Đà Nẵng. Không dựng thao tác kết nối/cập nhật như video quay màn hình. Không dùng ảnh quản lý token/API, danh sách đơn hoặc tracking cho Đoạn 4.
## Privacy
Bản dự án xuất chỉ chứa ảnh kho đã che cố định, không chứa ảnh gốc có thông tin riêng tư hoặc các ảnh không dùng. Không suy diễn tên người liên hệ từ tài khoản cá nhân. Ảnh thực tế được chú thích là ảnh chụp cấu hình của dự án demo.

## Revision v2
Bỏ toàn bộ ghi chú chân cảnh và số thứ tự chân cảnh. Thông tin cá nhân làm mờ bằng blur cố định trên ảnh, không thêm khung che hoặc chữ báo đã che.
