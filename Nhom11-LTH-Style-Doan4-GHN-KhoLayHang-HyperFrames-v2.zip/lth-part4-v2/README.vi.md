# Đoạn 4 — GHN và kho lấy hàng · v2

60 giây · 4K 3840×2160 · 16:9 · 30fps · Không lời thoại, không âm thanh. Màu burgundy–kem, chuyển cảnh fade nhẹ.

Bản v2 bỏ ghi chú và số thứ tự chân cảnh, thay khung che bằng blur số điện thoại và địa chỉ chi tiết; không có chữ thông báo đã che trên video. Giữ tên kho, khu vực và nội dung chính.

Ảnh kho đã được làm mờ cố định trước khi đưa vào composition; gói dự án không chứa ảnh gốc chưa làm mờ.

## Dựng lại
Cần Node.js 22+, FFmpeg, Chromium; HyperFrames ghim 0.9.38.

```bash
npm run check
npm run render -- --output doan4-v2.mp4 --fps 30 --quality high
```

index.html là composition, build.py tái tạo HTML. assets/ chứa ảnh đã chọn và xử lý, logo GHN và font.
