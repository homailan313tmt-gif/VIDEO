# Đoạn 1 — Nhóm 11 · LTH Style

60 giây · 3840 × 2160 · 16:9 · 30 fps · Không lời thoại, không có âm thanh.

Phong cách infographic 2D, burgundy #800020 và trắng kem #FFF8EC. Chỉ hiển thị Nhóm 11 và lớp 49K22.4; không liệt kê thành viên, không tạo logo LTH Style. Dùng nguyên logo GHN và hai ảnh website/Haravan người dùng cung cấp trong ảnh.zip.

## Thời gian
- 00:00–00:12: Giới thiệu nhóm và chủ đề hậu cần đầu ra.
- 00:12–00:19: LTH Style, Haravan, nội thành Đà Nẵng, ảnh website thực tế.
- 00:19–00:26: Ba thẻ áo, quần, váy lấy từ ảnh website.
- 00:26–00:48: In-house kết hợp GHN; vai trò Haravan; kiện hàng đi từ cửa hàng qua GHN đến khách.
- 00:48–01:00: Sản phẩm → Tồn kho → Xử lý đơn → Giao nhận; phóng vào ảnh danh sách sản phẩm Haravan.

## Dựng lại
Node.js 22+, FFmpeg và Chromium. CLI được ghim ở hyperframes 0.9.38.

```bash
npm run check
npm run render -- --output doan1.mp4 --fps 30 --quality high
```

index.html là composition HyperFrames có timeline GSAP xác định trước; font và hình ảnh được lưu cục bộ trong assets/. Ảnh nguồn có độ phân giải thấp hơn 4K; khung video và các thành phần chữ/infographic được dựng ở 4K.
