# LTH Style — Đoạn 1

## Style Prompt
Infographic 2D về hậu cần đầu ra của thương mại điện tử thời trang nữ. Nền kem, tiêu đề burgundy, nhiều khoảng trống, biểu tượng nét đồng nhất. Dùng ảnh thật website và Haravan được cung cấp. Không có lời thoại hoặc danh sách thành viên.

## Colors
- Burgundy #800020: tiêu đề, đường nối, biểu tượng chính.
- Cream #FFF8EC: nền.
- Ink #302327: nội dung.
- Blush #EEDDE1: nền thẻ.
- GHN: giữ nguyên màu logo gốc được cung cấp.

## Typography
Be Vietnam Pro, 400/600/800. Bố cục gốc 3840×2160. Tiêu đề 120–160px; nội dung 60–76px; nhãn 44–52px. Lề an toàn 200px.

## Motion
GSAP, timeline paused và xác định trước. Thẻ xuất hiện lệch nhịp 0.15s; đường nối và kiện hàng thể hiện luồng vận hành. Chuyển cảnh bằng lớp kem phủ 0.6s. Giữ thời gian đọc 3–5s mỗi nhóm ý. Cảnh cuối phóng vào Sản phẩm và nối với ảnh Haravan thật.

## What NOT to Do
- Không tạo logo LTH Style hay logo nhóm.
- Không thêm tên hoặc ảnh từng thành viên.
- Không tạo giọng đọc.
- Không giả giao diện website hoặc Haravan là ảnh thực tế.
- Không đổi màu logo GHN.
