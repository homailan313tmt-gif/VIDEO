# Odoo V1 · Visual identity

## Style Prompt
A precise, quiet technical demonstration for LTH Style. White and very pale lavender canvas, Odoo purple headings, large original screen recordings, restrained chapter cards and Vietnamese labels. Preserve the original UI pixels and data; use only framing, cuts, pauses and gentle zooms to make the operations legible. User chose technical clarity, light canvas and Odoo purple.

## Colors
- #FFFFFF — canvas and media backing
- #F6F2F6 — chapter ground
- #714B67 — Odoo purple, section indicators and focus borders
- #29232A — main text
- #625765 — secondary text

## Typography
Be Vietnam Pro, locally embedded from the official Google Fonts repository. Regular 400 for explanations, Black 900 for titles. All added Vietnamese copy uses NFC accents. No text is painted over original Odoo fields.

## Motion
0.24-second cross-dissolves; 0.35–0.5-second text entrances. Gentle scale changes capped at 1.2 on original screen footage. Extended pauses are marked “Dừng hình để đối chiếu”. No cursor simulation. No narration or source audio.

## What NOT to Do
- Do not reconstruct Odoo screens or replace figures, labels or states.
- Do not confuse Đen, S in the V1 overview with Đen, M in the detailed demo.
- Do not infer missing quantities, RFQ actions, warehouse location or payment states.
- Do not place labels over source data or use AI enhancement.
- Do not use fast effects, background music, or decorative motion that distracts from operations.
