# Bản dựng Odoo · V1, 4.1, 4.2

Bản dựng không lời thuyết minh, không âm thanh nguồn, nền sáng và tím Odoo. Thời lượng 113,2 giây. MP4 xuất 3840 × 2160, 30 fps. Nguồn là Full HD và khoảng 2.5K; 4K là độ phân giải đầu ra, không phải cảnh quay 4K gốc.

## Nội dung
- 00:00: Giới thiệu và tổng quan V1; dùng clip thô thaotacOdoo v1, ví dụ Quần ống rộng nữ Đen, S.
- 00:33: 4.1 — Danh sách sản phẩm, nhóm danh mục, danh sách biến thể; chuyển rõ sang Quần ống rộng nữ Đen, M (LTH-Q001-DEN-M).
- 01:10: 4.2 — Nhà cung cấp, bảng giá nhập hàng, PO P00008, số lượng 28, đơn giá 175.000 đ, ngày nhận dự kiến và liên kết phiếu nhập LTH/IN/00003.
- 01:49: Thẻ nối sang phần 4.3.

Không sửa hoặc dựng lại giao diện/số liệu Odoo. Chỉ cắt cảnh, giữ khung hình, đổi khung phóng to và thêm nhãn ngoài vùng dữ liệu. Các đoạn giữ ảnh gốc có nhãn “Dừng hình để đối chiếu”. Không khẳng định tồn thiếu, lượng cần mua hoặc hoàn thành đơn hàng khi chưa có chứng cứ.

## Phạm vi nguồn
Đã tải và xem 7/9 clip. Hai clip 4.1.2.mp4 và 4.2.4.mp4 vượt giới hạn tải 32 MiB/tệp nên chưa có trong bản này. Cần gửi bản nén hoặc chia nhỏ dưới 32 MiB để bổ sung đầy đủ phần thao tác, đặc biệt cảnh RFQ nếu có trong hai tệp này.
4.1.4.mp4 thuộc bảng giá xả hàng V2 nên để dành ngoài phạm vi. v1 (2).mp4 là bản tổng quan đã dựng; dùng footage thô tương ứng để làm rõ thao tác và thống nhất hình thức.

## Mở và xuất lại
Dùng dự án ở thư mục hiện tại. Không cần thay đổi cấu hình môi trường đã xuất bản.
- `npx --yes hyperframes@0.8.216 check`
- `HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.8.216 render --output renders/LTH-Odoo-V1-4.1-4.2-4K.mp4 --fps 30 --resolution landscape-4k --quality high --crf 16 --workers 2 --video-frame-format png`

Trong máy đám mây, Chrome/localhost có thể cần quyền mạng của công cụ thực thi. Giữ nguyên proxy và xác minh TLS.
`edit-plan.json` ghi timeline và các nguồn chưa truy cập được. `source-edits.json` ghi điểm cắt và đoạn dừng hình. `index.html` là nguồn HyperFrames, dùng phông Be Vietnam Pro được nhúng cục bộ.

## Kiểm tra
Lint, runtime, layout, motion và contrast: đạt (`check-final.json`). Các cảnh tĩnh được giữ có chủ đích để đọc dữ liệu; video không có âm thanh. Các dòng thông tin phụ nhỏ hơn mức đề xuất cho màn hình điện thoại vì ưu tiên diện tích giao diện Odoo và đầu ra YouTube 16:9.
