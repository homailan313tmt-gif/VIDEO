from pathlib import Path
import json

p = Path(__file__).parent

css = r'''
@font-face{font-family:BeVN;src:url(assets/fonts/BeVietnamPro-Regular.ttf);font-weight:400;font-display:block}
@font-face{font-family:BeVN;src:url(assets/fonts/BeVietnamPro-Black.ttf);font-weight:800 900;font-display:block}
:root{--b:#800020;--c:#fff8ec;--ink:#302327;--p:#eedde1;--line:#dac5c8;--muted:#73505a}
*{box-sizing:border-box;margin:0;padding:0}
html,body,#main{width:3840px;height:2160px;overflow:hidden;background:var(--c);font-family:BeVN,sans-serif;color:var(--ink)}
#main{position:relative;font-variant-numeric:tabular-nums}.scene{position:absolute;inset:0;background:var(--c)}
.scene-content{width:100%;height:100%;padding:110px 160px 100px;display:flex;flex-direction:column;gap:45px}
.top{display:flex;justify-content:space-between;border-bottom:2px solid var(--line);padding-bottom:32px;color:var(--b);font-size:36px;font-weight:800;letter-spacing:4px;flex-shrink:0}
.heading{display:flex;flex-direction:column;gap:14px;flex-shrink:0}.kicker{font-size:38px;letter-spacing:4px;font-weight:800;color:var(--b)}
h1{font-size:112px;font-weight:900;color:var(--b);letter-spacing:-4px;line-height:1.2}.heading>p{font-size:54px;color:var(--muted)}
.body{display:flex;gap:100px;flex:1;min-height:0;align-items:center}
.photo{border:3px solid var(--b);border-radius:28px;overflow:hidden;background:white;box-shadow:18px 18px 0 var(--p);flex-shrink:0}
.photo>img{display:block;width:100%;height:100%;object-fit:cover}.parcel{width:1090px;height:1450px}.parcel>img{object-position:center}
.intro-copy{flex:1;display:flex;flex-direction:column;gap:52px}.intro-copy>h2{font-size:102px;font-weight:900;line-height:1.35;color:var(--b);max-width:1980px;letter-spacing:-3px}
.route{display:flex;align-items:center;gap:50px;padding:38px 55px;border:2px solid var(--line);border-radius:24px;background:var(--p);color:var(--b);font-size:76px;font-weight:800;align-self:flex-start}.route img{width:148px;height:148px;border-radius:22px}.route .arr{font-size:95px}
.check-line{display:flex;gap:32px;align-items:center;padding:30px 0;border-bottom:2px solid var(--line)}.check-line>b{width:72px;height:72px;border:3px solid var(--b);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:43px;color:var(--b)}.check-line p{font-size:67px;line-height:1.4}.check-line strong{color:var(--b);font-weight:800}
.label-card{width:1090px;height:1508px;border:3px solid var(--b);border-radius:28px;background:white;overflow:hidden;box-shadow:18px 18px 0 var(--p);flex-shrink:0;display:flex;flex-direction:column}
.screen-label{display:flex;align-items:center;flex-shrink:0;height:100px;padding:0 40px;font-size:38px;font-weight:800;letter-spacing:4px;background:var(--b);color:var(--c)}
.label-card>img{width:100%;height:1402px;object-fit:contain}.label-copy{flex:1;display:flex;flex-direction:column;gap:38px}.label-copy .code{font-size:162px;letter-spacing:-7px;line-height:1.2;color:var(--b);font-weight:900}
.info{display:flex;flex-direction:column;gap:18px;padding:20px 0 35px;border-bottom:2px solid var(--line)}.info small{font-size:36px;letter-spacing:4px;color:var(--muted)}.info strong{font-size:68px;color:var(--b);line-height:1.4}.info p{font-size:54px;line-height:1.5}.info .sku{font-size:68px;letter-spacing:-2px;white-space:nowrap}
.pill-row{display:flex;gap:28px}.pill{font-size:55px;font-weight:800;color:var(--b);padding:25px 35px;background:var(--p);border-radius:20px;white-space:nowrap}
.tracking-row{align-items:stretch;gap:145px}.tracking-card{width:1015px;flex-shrink:0;background:white;border:3px solid var(--b);border-radius:28px;overflow:hidden;box-shadow:18px 18px 0 var(--p);display:flex;flex-direction:column;justify-content:center}.tracking-card>img{display:block;width:100%;height:100%;min-height:0;object-fit:contain}
.timeline{flex:1;display:flex;flex-direction:column;justify-content:space-between;gap:18px;padding:10px 0;min-height:0}.event{display:flex;gap:34px;align-items:center;min-height:230px;padding:30px 38px;border:2px solid var(--line);background:var(--p);border-radius:23px}.event .date{font-size:46px;color:var(--muted);width:260px;flex-shrink:0;line-height:1.5}.event .date strong{font-size:61px;color:var(--b);display:block}.event .dot{width:34px;height:34px;border-radius:50%;background:var(--b);flex-shrink:0}.event .event-copy{flex:1;display:flex;flex-direction:column;gap:14px}.event h3{font-size:65px;color:var(--b);font-weight:800;line-height:1.25;letter-spacing:-1px}.event p{font-size:45px;line-height:1.45;color:var(--ink)}.event.final{background:var(--b);border-color:var(--b);color:var(--c)}.event.final .date,.event.final .date strong,.event.final h3,.event.final p{color:var(--c)}.event.final .dot{background:var(--c)}
.success-row{gap:105px;align-items:stretch}.success-copy{flex:1;display:flex;flex-direction:column;gap:46px;justify-content:center}.success-stamp{display:flex;align-items:center;gap:35px;color:var(--b)}.success-stamp>b{font-size:90px;border:5px solid var(--b);border-radius:50%;width:150px;height:150px;display:flex;align-items:center;justify-content:center;flex-shrink:0}.success-stamp h2{font-size:105px;line-height:1.3;font-weight:900;letter-spacing:-2px}.success-time{font-size:112px;font-weight:900;color:var(--b);letter-spacing:-3px}.proof-success{border:3px solid var(--b);background:white;border-radius:26px;overflow:hidden;box-shadow:16px 16px 0 var(--p);display:flex;flex-direction:column;flex-shrink:0}.proof-success>img{width:100%;height:600px;object-fit:contain;display:block}.success-copy>.info p{font-size:61px}.success-row .parcel{width:1030px;height:1373px;align-self:center}
.payment{display:flex;flex-direction:column;gap:45px;flex:1;min-height:0;justify-content:center}.fee-card{border:3px solid var(--b);border-radius:26px;background:white;overflow:hidden;box-shadow:18px 18px 0 var(--p);flex-shrink:0}.fee-card>img{display:block;width:100%;height:500px;object-fit:contain}
.money-grid{display:flex;gap:70px}.money{flex:1;border:2px solid var(--line);border-radius:26px;background:var(--p);padding:38px 55px;display:flex;flex-direction:column;gap:20px}.money small{font-size:41px;letter-spacing:3px;font-weight:800;color:var(--muted)}.money strong{font-size:144px;letter-spacing:-6px;font-weight:900;color:var(--b);line-height:1.15}.money p{font-size:54px;line-height:1.5}.money.dark{background:var(--b);border-color:var(--b);color:var(--c)}.money.dark small,.money.dark strong{color:var(--c)}
.payment-copy{display:flex;align-items:center;gap:50px;padding:8px 0}.payment-copy img{width:125px;height:125px;border-radius:20px;flex-shrink:0}.payment-copy p{font-size:57px;line-height:1.5;max-width:3100px;color:var(--b)}
.next{display:flex;gap:50px;align-items:center;padding:28px 42px;border-top:2px solid var(--line);color:var(--b)}.next small{font-size:35px;letter-spacing:4px;font-weight:800;flex-shrink:0}.next strong{font-size:58px;line-height:1.5}
'''

content = [
('Bàn giao kiện cho GHN','Đối chiếu mã vận đơn trước khi bàn giao',r'''
<div class="body"><div class="photo parcel"><img src="assets/handoff.jpg" alt="Bàn giao kiện cho nhân viên GHN"/></div>
<div class="intro-copy"><h2>Bàn giao kiện đã đóng gói cho GHN</h2><div class="route"><span>LTH Style</span><span class="arr">→</span><img src="assets/ghn.png" alt="GHN"/><span>GHN</span></div>
<div class="check-line c1"><b>✓</b><p>Đối chiếu <strong>mã vận đơn</strong> trên kiện</p></div>
<div class="check-line c2"><b>✓</b><p>Kiểm tra <strong>tình trạng bao gói</strong></p></div>
<div class="check-line c3"><b>✓</b><p>Ghi nhận hình ảnh <strong>bàn giao</strong></p></div></div></div>'''),
('Đối chiếu phiếu gửi GHN','Cùng mã vận đơn trên phiếu và trên kiện',r'''
<div class="body"><div class="label-card"><div class="screen-label">PHIẾU GỬI GHN</div><img src="assets/waybill-safe.png" alt="Phiếu gửi GYENL6TA"/></div>
<div class="label-copy"><div class="kicker">MÃ VẬN ĐƠN</div><div class="code">GYENL6TA</div>
<div class="info product"><small>SẢN PHẨM</small><strong>Áo 2 dây viền cổ phối ren</strong><p class="sku">LTH-A2D-REN-001-TR-FS</p></div>
<div class="pill-row"><span class="pill">Màu Trắng</span><span class="pill">Số lượng: 1</span></div>
<div class="info delivery"><small>ĐIỂM NHẬN</small><strong>Hoàng Diệu · Đà Nẵng</strong></div>
<div class="info created"><small>THỜI ĐIỂM TẠO ĐƠN</small><strong>11/11/2026 · 17:38</strong></div></div></div>'''),
('Theo dõi hành trình GHN','Đối chiếu từng trạng thái với thời gian cập nhật',r'''
<div class="body tracking-row"><div class="tracking-card"><img src="assets/tracking-safe.png" alt="Nhật ký hành trình GHN"/></div><div class="timeline">
<div class="event e0"><div class="date">11/11<strong>17:38</strong></div><span class="dot"></span><div class="event-copy"><h3>Tạo đơn</h3><p>Dự kiến lấy hàng: 12/11/2026</p></div></div>
<div class="event e1"><div class="date">12/11<strong>16:29</strong></div><span class="dot"></span><div class="event-copy"><h3>Đang lấy hàng</h3><p>Kho (DNG) Ngũ Hành Sơn</p></div></div>
<div class="event e2"><div class="date">13/11<strong>08:04</strong></div><span class="dot"></span><div class="event-copy"><h3>Đang vận chuyển</h3><p>Bưu cục giao (DNG) Hòa Cường</p></div></div>
<div class="event e3"><div class="date">13/11<strong>08:04</strong></div><span class="dot"></span><div class="event-copy"><h3>Đang giao hàng</h3><p>Nhân viên đang trên đường giao</p></div></div>
<div class="event final e4"><div class="date">13/11<strong>15:59</strong></div><span class="dot"></span><div class="event-copy"><h3>Giao hàng thành công</h3><p>Địa điểm ghi nhận: Hoàng Diệu</p></div></div>
</div></div>'''),
('GHN cập nhật giao thành công','Đọc kết quả trên nhật ký hành trình',r'''
<div class="body success-row"><div class="success-copy"><div class="success-stamp"><b>✓</b><h2>Giao hàng thành công</h2></div><div class="success-time">13/11 · 15:59</div>
<div class="proof-success"><div class="screen-label">TRẠNG THÁI TRÊN TRACKING GHN</div><img src="assets/delivered-safe.png" alt="Trạng thái giao thành công lúc 15:59 ngày 13/11"/></div>
<div class="info result"><small>ĐỊA ĐIỂM CẬP NHẬT</small><strong>Hoàng Diệu · Đà Nẵng</strong><p>Lưu thông tin hành trình để đối chiếu sau giao hàng.</p></div></div>
<div class="photo parcel"><img src="assets/parcel-safe.png" alt="Ảnh kiện có phiếu gửi GYENL6TA"/></div></div>'''),
('Tiền thu hộ và cước vận chuyển','Phân biệt khoản thu hộ với phí giao hàng',r'''
<div class="payment"><div class="fee-card"><div class="screen-label">THÔNG TIN CƯỚC TRÊN GHN</div><img src="assets/fee-detail-safe.png" alt="Thông tin thu hộ và cước GHN"/></div>
<div class="money-grid"><div class="money cod"><small>TIỀN THU HỘ · COD</small><strong>0đ</strong><p>Không thu hộ tiền hàng</p></div><div class="money dark fee"><small>CƯỚC VẬN CHUYỂN</small><strong>16.500đ</strong><p>Người nhận thanh toán</p></div></div>
<div class="payment-copy"><img src="assets/ghn.png" alt="GHN"/><p>Giao thành công và đối soát là hai thông tin được theo dõi riêng.</p></div>
<div class="next"><small>TIẾP THEO</small><strong>Nhận hàng · Hoàn trả · Đổi hàng</strong></div></div>''')
]
starts=[0,16,30,75,100]
ends=[16,30,75,100,120]
scenes=[]
for i,(title,sub,body) in enumerate(content):
    d=ends[i]-starts[i]+(.65 if i<4 else 0)
    scenes.append(f'''<section id="s{i}" class="clip scene" style="z-index:{i*10}" data-start="{starts[i]}" data-duration="{d}" data-track-index="{i+1}"><div class="scene-content" data-layout-allow-overlap data-hold="Khoảng dừng để đọc ảnh chụp và đối chiếu mốc tracking"><div class="top"><span>NHÓM 11 · LỚP 49K22.4</span><span>ĐOẠN 06 · TRACKING, GIAO HÀNG VÀ COD</span></div><div class="heading"><div class="kicker">LTH STYLE · HẬU CẦN ĐẦU RA</div><h1>{title}</h1><p>{sub}</p></div>{body}</div></section>''')

js="window.__timelines=window.__timelines||{};const tl=gsap.timeline({paused:true});\n"
for i,t in enumerate(starts):
    if i: js+=f"tl.from('#s{i}',{{opacity:0,duration:.6,ease:'sine.inOut'}},{t});\n"
    js+=f"tl.from('#s{i} .top',{{opacity:0,duration:.6,ease:'power1.out'}},{t+.12});\n"
    js+=f"tl.from('#s{i} .heading',{{opacity:0,duration:.75,ease:'sine.out'}},{t+.25});\n"
js+=r'''
tl.from('#s0 .parcel',{opacity:0,duration:1,ease:'power2.out'},.6);
tl.from('#s0 .intro-copy>h2',{opacity:0,duration:.8,ease:'sine.out'},1);
tl.from('#s0 .route',{opacity:0,duration:.8,ease:'power1.out'},2.3);
tl.from('#s0 .c1',{opacity:0,duration:.8,ease:'power2.out'},4);
tl.from('#s0 .c2',{opacity:0,duration:.8,ease:'sine.out'},7.5);
tl.from('#s0 .c3',{opacity:0,duration:.8,ease:'power1.out'},11);
tl.from('#s1 .label-card',{opacity:0,duration:.85,ease:'power2.out'},16.6);
tl.from('#s1 .label-copy>.kicker,#s1 .code',{opacity:0,duration:.8,stagger:.3,ease:'sine.out'},17);
tl.from('#s1 .product',{opacity:0,duration:.8,ease:'power1.out'},19);
tl.from('#s1 .pill-row',{opacity:0,duration:.75,ease:'sine.out'},21);
tl.from('#s1 .delivery',{opacity:0,duration:.8,ease:'power2.out'},23);
tl.from('#s1 .created',{opacity:0,duration:.8,ease:'power1.out'},26);
tl.from('#s2 .tracking-card',{opacity:0,duration:.9,ease:'power2.out'},30.6);
tl.from('#s2 .e0',{opacity:0,duration:.8,ease:'sine.out'},31.5);
tl.from('#s2 .e1',{opacity:0,duration:.8,ease:'power1.out'},38.5);
tl.from('#s2 .e2',{opacity:0,duration:.8,ease:'power2.out'},46);
tl.from('#s2 .e3',{opacity:0,duration:.8,ease:'sine.out'},54);
tl.from('#s2 .e4',{opacity:0,duration:.9,ease:'power1.out'},63);
tl.from('#s3 .parcel',{opacity:0,duration:.85,ease:'power2.out'},75.6);
tl.from('#s3 .success-stamp',{opacity:0,duration:.8,ease:'sine.out'},76);
tl.from('#s3 .success-time',{opacity:0,duration:.8,ease:'power1.out'},78);
tl.from('#s3 .proof-success',{opacity:0,duration:.9,ease:'power2.out'},81);
tl.from('#s3 .result',{opacity:0,duration:.8,ease:'sine.out'},90);
tl.from('#s4 .fee-card',{opacity:0,duration:.9,ease:'power2.out'},100.6);
tl.from('#s4 .cod',{opacity:0,duration:.8,ease:'sine.out'},102);
tl.from('#s4 .fee',{opacity:0,duration:.8,ease:'power1.out'},105);
tl.from('#s4 .payment-copy',{opacity:0,duration:.8,ease:'power2.out'},110);
tl.from('#s4 .next',{opacity:0,duration:.8,ease:'sine.out'},115);
window.__timelines.main=tl;
'''
html='<!doctype html><html lang="vi"><head><meta charset="utf-8"><script src="assets/gsap.min.js"></script><style>'+css+'</style></head><body><main id="main" data-composition-id="main" data-start="0" data-duration="120" data-width="3840" data-height="2160" data-fps="30">'+''.join(scenes)+'</main><script>'+js+'</script></body></html>'
(p/'index.html').write_text(html)
(p/'meta.json').write_text(json.dumps({'id':'lth-style-doan6-v2','name':'LTH Style — Đoạn 6 v2: Bàn giao, tracking và COD','width':3840,'height':2160,'fps':30,'duration':120},ensure_ascii=False,indent=2)+'\n')
pkg=json.loads((p/'package.json').read_text());pkg['name']='lth-part6-v2';(p/'package.json').write_text(json.dumps(pkg,indent=2)+'\n')
(p/'storyboard.json').write_text(json.dumps([{'start':starts[i],'end':ends[i],'title':c[0],'subtitle':c[1]} for i,c in enumerate(content)],ensure_ascii=False,indent=2)+'\n')
