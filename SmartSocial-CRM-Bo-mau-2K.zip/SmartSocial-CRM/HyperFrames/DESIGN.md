# SmartSocial CRM

## Phong cách
Nền xanh đêm, đường kẻ mảnh gợi lưới tấm pin mặt trời, chi tiết hổ phách và xanh ngọc. Bố cục ưu tiên bản quay giao diện, tiêu đề và chữ mô tả đặt bên trái. Thẻ mở đầu và kết thúc dùng hình học đồng bộ với nền.

## Màu
- #0B1724 nền
- #112536 bề mặt và khung
- #F3F5F3 chữ chính
- #B8CBD3 chữ mô tả
- #F3C478 hổ phách, dùng cho dấu hiệu nhận diện
- #88D8C7 xanh ngọc, dùng cho các phần về quy trình và phân tích

## Chữ và chuyển động
Be Vietnam Pro cho nội dung tiếng Việt, IBM Plex Mono cho mã cảnh và mốc dựng. Hòa cảnh nhẹ, giữ bố cục tĩnh trong khi người xem theo dõi thao tác.

## Tránh
Tránh hiệu ứng chuyển nhanh, chữ đè lên màn hình thao tác, minh họa giả làm giao diện sản phẩm và chi tiết trang trí trong vùng video.
