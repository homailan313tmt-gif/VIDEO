# SmartSocial CRM · Bộ mẫu dựng video

Bộ mẫu dành cho video demo Hùng Hiền Solar, khung ngang 2K, 2560 × 1440 (16:9), dài 15 phút, gồm 25 vị trí chèn clip và hai thẻ mở đầu, kết thúc. Bản nền không có track âm thanh.

## Ghép nhanh trong phần mềm dựng

1. Đặt `SmartSocial-CRM-Backdrop-2K-15phut.mp4` lên track nền của timeline 2560 × 1440, 30 fps, bắt đầu tại 00:00.
2. Tra `Timeline.csv` để cắt bản quay và đặt clip trên track phía trên theo thời gian và số video nguồn. Clip nguồn dùng cho nhiều cảnh thì cắt lấy đoạn thao tác tương ứng.
3. Giữ tỷ lệ hình và căn clip vào khung bên phải. Tọa độ theo góc trên trái là **X 717, Y 239**, kích thước **1744 × 981 px**. Với màn hình nguồn 2560 × 1440, dùng tỷ lệ **68,125%** nếu phần mềm đang hiển thị clip ở đúng 2560 × 1440 tại mức 100%. Tâm khung ở **X 1589, Y 729,5**, lệch 309 px sang phải và 9,5 px xuống so với tâm canvas.
4. Với clip khác tỷ lệ, dùng cắt khung để lấp đầy nếu phần thao tác vẫn đọc được. Nếu muốn giữ trọn clip và có dải đệm hai bên, dùng cách PNG bên dưới. Giữ âm thanh gốc theo nhu cầu của bạn.

## Dùng PNG để thay đổi thời lượng từng cảnh

- Đặt ảnh tương ứng trong `PNG-overlays/` **phía trên** clip quay. Ảnh có một vùng trong suốt đúng kích thước khung bên phải. Căn clip ở track dưới sao cho nằm trong vùng đó. Đặt một nền tối ở track dưới cùng nếu clip không lấp hết vùng trong suốt.
- Kéo dài hoặc rút ngắn mỗi ảnh tùy thời lượng thao tác. Hai ảnh `Mo-dau.png` và `Ket-thuc.png` phủ kín màn hình. Tên các ảnh còn lại bắt đầu bằng thứ tự dựng rồi tới số cảnh gốc.
- `Timeline.csv` có cả nội dung chữ để dùng lại nếu muốn sửa tiêu đề hoặc mô tả trực tiếp trong trình dựng.

## Chỉnh chữ trong HyperFrames

Nguồn thiết kế nằm trong `HyperFrames/`. Các tiêu đề, mô tả và dòng nhấn sửa được trong `index.html`. CSS, phông chữ và ảnh nền nằm cùng project. Từ thư mục `HyperFrames`, chạy `npx hyperframes preview` để mở Studio, hoặc `npx hyperframes render --output SmartSocial-CRM.mp4` để xuất lại video.

Muốn lắp clip trong nguồn, tạo thư mục `HyperFrames/media`, đặt clip vào đó rồi bỏ dấu chú thích quanh thẻ `<video>` của đúng cảnh trong phần “Vị trí chèn video” ở cuối `index.html`. Sửa `src` theo tên tệp và `data-media-start` theo số giây cần cắt ở đầu clip. Giữ các mốc `data-start` và `data-duration` để khớp nền. Các thẻ video đặt mặc định ở chế độ tắt tiếng.

## Mốc phân đoạn

| Thời gian | Nội dung |
| --- | --- |
| 00:00–02:00 | Đăng nhập, phân quyền và kết nối Fanpage |
| 02:00–04:30 | Webhook, tự động hóa A1–A3, AI Copilot và gửi phản hồi |
| 04:30–07:00 | Unified Inbox và phối hợp xử lý hội thoại |
| 07:00–09:00 | Customer 360, Customer Journey và ghép hồ sơ |
| 09:00–11:00 | Sản phẩm, đơn hàng, Task/Follow-up và Customer Owner |
| 11:00–12:30 | Thông báo, SLA và điều phối |
| 12:30–15:00 | Dashboard, RFM và tổng kết |

Các mốc từng cảnh được chia từ thời lượng phân đoạn trong kịch bản. Cảnh 09 và 10 giữ vị trí theo thứ tự xuất hiện trong bản gốc, sau Cảnh 05 và trước Cảnh 06. Bản nền có thẻ mở đầu từ 00:00 đến 00:07 và thẻ kết thúc từ 14:50 đến 15:00.
