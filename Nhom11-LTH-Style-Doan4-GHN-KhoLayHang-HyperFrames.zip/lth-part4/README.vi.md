# Đoạn 4 — Cấu hình GHN và kho lấy hàng

Nhóm 11 · Lớp 49K22.4 · LTH Style.

60 giây · 3840×2160 · 16:9 · 30fps · Không lời thoại, không âm thanh. Burgundy #800020 và kem #FFF8EC, chuyển cảnh fade nhẹ 0.6 giây.

## Nội dung
- 00:00–00:15: GHN trong khu vực nhà vận chuyển bên thứ ba trên Haravan.
- 00:15–00:30: Phóng to tài khoản kết nối, trạng thái “Đã kết nối”; quan hệ Haravan → GHN.
- 00:30–00:48: Thông tin cửa hàng LTH Style Đà Nẵng trên GHN; khu vực Ngũ Hành Sơn, Đà Nẵng; số điện thoại và địa chỉ chi tiết đã che.
- 00:48–01:00: Ba nội dung kiểm tra trước khi GHN nhận kiện: kho lấy hàng, địa chỉ, thông tin liên hệ; dẫn sang khách đặt và xử lý đơn hàng.

Khi ghép sau ba đoạn trước, phần này tương ứng 05:00–06:00.

## Ảnh được chọn
Từ ZIP người dùng cung cấp, sử dụng hai ảnh:
- 2aoborcntrcukqdrinunbkqdcsquww8etccutijs5.jpg: Haravan, GHN, trạng thái Đã kết nối.
- 2aoborcntt829kultdwm0f1fahxecankfftqdenq3.jpg: thông tin cửa hàng GHN, chỉ sử dụng vùng trung tâm đã che số điện thoại và địa chỉ chi tiết.

Ảnh API/token, danh sách đơn và nhật ký tracking không nằm trong video hoặc gói dự án này. Ảnh cấu hình là ảnh chụp màn hình, không mô phỏng thao tác bấm kết nối hoặc cập nhật. Không suy diễn tên người liên hệ từ thông tin tài khoản cá nhân. Khu vực công khai được lấy đúng từ ảnh.

Ảnh nguồn có độ phân giải thấp hơn 4K; khung hình, chữ và infographic được dựng ở 4K. Gói dự án chỉ chứa phiên bản ảnh kho đã che cố định; không chứa ảnh kho gốc có dữ liệu riêng tư.

## Chỉnh sửa và dựng lại
Node.js 22+, FFmpeg, Chromium. CLI HyperFrames ghim ở 0.9.38.

```bash
npm run check
npm run render -- --output doan4.mp4 --fps 30 --quality high
```

index.html là composition, build.py tái tạo HTML; assets/ chứa ảnh đã chọn, logo GHN và font cục bộ. Đã kiểm tra bằng HyperFrames check và xem khung hình chính trước khi xuất.
