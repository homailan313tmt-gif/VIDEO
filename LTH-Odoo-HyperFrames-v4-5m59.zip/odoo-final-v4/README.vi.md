# LTH Style · Odoo · Bản 04

Video chính: `LTH-Odoo-V1-den-Ket-4K-v4-5m59.mp4`.

- Thời lượng toàn bộ: **5 phút 59,067 giây** (10.772 khung hình ở 30 fps).
- Phần thao tác và các thẻ mục trước 4.5 kết thúc ở **4 phút 58,567 giây**.
- Xuất 3840 × 2160, 16:9, H.264, không âm thanh/thuyết minh.
- Nền sáng, tím Odoo, phông Be Vietnam Pro có đầy đủ dấu tiếng Việt.
- Cắt thẳng giữa các cảnh, không thêm hiệu ứng chuyển cảnh, không có thanh tiến độ chạy dưới video.

## Thay đổi trong bản này

Đã thêm đầy đủ hai clip `4.3.5-1.mp4` và `4.3.5-2.mp4`, nối thành 36,3 giây ở tốc độ gốc. Cảnh thể hiện bổ sung hàng, tạo RFQ P00008 và mở chi tiết yêu cầu báo giá. Chú thích xác định đây là bước tạo RFQ trước khi xác nhận, tránh hiểu thành một lần mua mới sau phiếu nhập đã trình bày.

Để giữ toàn bộ video dưới 6 phút, bỏ lượt tổng quan V1 và lượt xem danh sách biến thể bị lặp; vẫn giữ luồng thao tác chi tiết về sản phẩm, thuộc tính/biến thể, nhà cung cấp, RFQ, phiếu nhập, kho, vị trí, tồn kho, nhận hàng, bổ sung hàng và V2. Các clip thao tác được giữ lại đều chạy **1× và đủ từ đầu đến cuối**, không cắt giữa thao tác để rút thời lượng. Chỉ rút thời gian các thẻ chữ và ảnh tham chiếu ở phần báo cáo/kết.

## Mốc nội dung

| Mốc | Nội dung |
| --- | --- |
| 00:00 | V1 · Kiểm soát và bổ sung tồn kho |
| 00:03 | 4.1 · Sản phẩm và biến thể |
| 00:55 | 4.2 · Mua hàng và nguồn cung |
| 01:56 | 4.3 · Nhận hàng và kiểm tra tồn |
| 02:48 | 4.3.5 · Từ quy tắc bổ sung đến RFQ |
| 03:24 | V2 / 4.4 · Thực hiện đơn xả cuối mùa |
| 04:58 | 4.5 · Từ dữ liệu đến quyết định |
| 05:31 | Đề xuất vận hành và kết |

## Tính chính xác của dữ liệu

Các màn hình Odoo đến từ video gốc; không vẽ lại giao diện hoặc thay số liệu. P00008 của quần Đen, M khác P00006 của váy ở phần Receiving. Quy tắc bổ sung trong V2 đang hiển thị quần; đơn xả S00110 dùng váy LTH-V001-DEN-M. Chỉ ghi nhận hóa đơn đã thanh toán khi màn hình thực tế chứng minh trạng thái đó. Phần 4.5 dùng ảnh tham chiếu từ clip thật; số 5 đã giao và tồn hiện tại 26 được đọc tại các màn hình tương ứng, không suy diễn một phép biến động tồn kho chưa được chứng minh.

Video V2 gốc đã có zoom và đánh dấu bên trong. Dự án giữ phần Odoo, dùng khung cắt cố định để bỏ chú thích ngoài khung và dải bước dưới clip gốc. Không thêm zoom làm thay đổi nội dung thao tác.

## Chỉnh sửa và xuất lại

Dự án HyperFrames tự chứa toàn bộ tài nguyên đang dùng, gồm HTML, video, ảnh và phông chữ. Cần Node.js, FFmpeg và Chromium tương thích.

```bash
npm run check
npx hyperframes@0.8.216 preview --background
npx hyperframes@0.8.216 render --fps 30 --resolution landscape-4k --quality high --crf 16 --video-frame-format png --output renders/LTH-Odoo-v4.mp4
```

`edit-plan.json` mô tả thứ tự và thời lượng; các tệp `source-edits-*.json` ghi nguồn video. `assembly-edl.json` ghi các khoảng khung hình dùng để tận dụng các cảnh HyperFrames đã xuất trước đó. Bản giao được ghép đúng khung hình: sao chép nguyên chất lượng những cảnh bắt đầu ở keyframe, giải mã và mã hóa lại chính xác những điểm bắt đầu nằm giữa GOP. Không bỏ khung hình đầu thao tác do tìm keyframe.

`check.json` ghi kết quả kiểm tra đầy đủ. Các cảnh báo còn lại về video im lặng và cỡ chữ phụ được giữ theo yêu cầu và bố cục YouTube đã thống nhất. Giấy phép phông nằm ở `assets/fonts/OFL.txt`.
